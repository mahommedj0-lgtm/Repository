import React, { useState, useRef, useMemo, useCallback, useEffect } from "react";
import {
  Search, Plus, Pencil, Trash2, LogOut, Users, LayoutDashboard, Database,
  Upload, Download, X, Check, AlertTriangle, Package, Menu, ShieldCheck,
  Eye, EyeOff, RefreshCw, Sparkles, KeyRound, Mail, ChevronLeft, Save,
  ScanBarcode, ImageIcon, Boxes, Wallet, TriangleAlert, UserPlus, Lock,
  Camera, CameraOff, Receipt, ShoppingBag, FileSpreadsheet, ImagePlus
} from "lucide-react";

/* ---------------------------------- Design tokens ---------------------------------- */
const GLOBAL_CSS = `
@import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap');

.ra-root{
  --bg:#F7F6FA;
  --surface:#FFFFFF;
  --surface-alt:#F0EDF6;
  --ink:#211D29;
  --ink-soft:#57515F;
  --ink-mute:#8D8794;
  --primary:#DE3A73;
  --primary-dark:#B2245A;
  --primary-soft:#FBDFEA;
  --gold:#D6A03F;
  --gold-soft:#FAF0DA;
  --sage:#2E9E58;
  --sage-soft:#E1F5E8;
  --line:#E7E3EF;
  --danger:#E0342F;
  --danger-soft:#FCE3E2;
  --shadow: 0 10px 24px -14px rgba(30,15,35,0.22);
  --shadow-sm: 0 2px 10px -6px rgba(30,15,35,0.14);
  font-family: 'Tajawal', sans-serif;
  color: var(--ink);
  background: var(--bg);
  min-height: 100%;
  direction: rtl;
}
.ra-root *{ box-sizing: border-box; }
.ra-serif{ font-family: 'Tajawal', sans-serif; font-weight: 800; letter-spacing: -0.01em; }
.ra-scroll::-webkit-scrollbar{ width:6px; height:6px; }
.ra-scroll::-webkit-scrollbar-thumb{ background: var(--line); border-radius: 10px; }

.ra-btn{
  display:inline-flex; align-items:center; gap:8px; justify-content:center;
  padding:10px 18px; border-radius:12px; font-weight:700; font-size:14.5px;
  border:1px solid transparent; cursor:pointer; transition: background .12s ease, opacity .12s ease;
  white-space:nowrap;
}
.ra-btn:active{ opacity:.85; }
.ra-btn:disabled{ opacity:.45; cursor:not-allowed; }
.ra-btn-primary{ background: var(--primary); color:#fff; }
.ra-btn-primary:hover:not(:disabled){ background: var(--primary-dark); }
.ra-btn-gold{ background: var(--gold); color:#2E2320; }
.ra-btn-gold:hover:not(:disabled){ filter:brightness(0.94); }
.ra-btn-ghost{ background: transparent; color: var(--ink-soft); border-color: var(--line); }
.ra-btn-ghost:hover:not(:disabled){ background: var(--surface-alt); }
.ra-btn-danger{ background: var(--danger-soft); color: var(--danger); }
.ra-btn-danger:hover:not(:disabled){ background: var(--danger); color:#fff; }
.ra-btn-sm{ padding:7px 12px; font-size:13px; border-radius:10px; }
.ra-icon-btn{
  display:inline-flex; align-items:center; justify-content:center; width:38px; height:38px;
  border-radius:10px; border:1px solid var(--line); background: var(--surface); color: var(--ink-soft);
  cursor:pointer; transition: background .12s ease;
}
.ra-icon-btn:hover{ background: var(--surface-alt); }

.ra-input{
  width:100%; padding:11px 14px; border-radius:11px; border:1.5px solid var(--line);
  background: var(--surface); color: var(--ink); font-family:'Tajawal',sans-serif; font-size:14.5px;
  transition: border-color .12s ease, box-shadow .12s ease; outline:none;
}
.ra-input:focus{ border-color: var(--primary); box-shadow: 0 0 0 3px var(--primary-soft); }
.ra-label{ font-size:13px; font-weight:700; color: var(--ink-soft); margin-bottom:6px; display:block; }

.ra-card{
  background: var(--surface); border:1px solid var(--line); border-radius:16px;
  box-shadow: var(--shadow-sm);
}
.ra-hairline{ border-top:1px solid var(--line); }

.ra-badge{
  display:inline-flex; align-items:center; gap:5px; padding:4px 11px; border-radius:999px;
  font-size:12px; font-weight:700; white-space:nowrap;
}
.ra-fade-in{ animation: raFade .2s ease; }
@keyframes raFade{ from{ opacity:0;} to{opacity:1;} }
.ra-pop{ animation: raPop .18s ease; }
@keyframes raPop{ from{ opacity:0; transform: scale(.97);} to{opacity:1; transform:scale(1);} }

.ra-scrollbar-none::-webkit-scrollbar{ display:none; }

.ra-nav-item{
  display:flex; align-items:center; gap:12px; padding:12px 14px; border-radius:12px;
  color: var(--ink-soft); font-weight:700; font-size:15px; cursor:pointer;
  transition: background .12s ease, color .12s ease;
}
.ra-nav-item:hover{ background: var(--surface-alt); }
.ra-nav-item.active{ background: var(--primary); color:#fff; }

.ra-toggle{
  width:42px; height:24px; border-radius:999px; position:relative; cursor:pointer;
  transition: background .15s ease; border:none; flex-shrink:0;
}
.ra-toggle span{
  position:absolute; top:2px; right:2px; width:20px; height:20px; border-radius:999px;
  background:#fff; transition: transform .15s ease; box-shadow:0 1px 3px rgba(0,0,0,.25);
}
.ra-toggle.on{ background: var(--primary); }
.ra-toggle.on span{ transform: translateX(-18px); }
.ra-toggle.off{ background:#DDD8E3; }

@media (max-width: 860px){
  .ra-sidebar{ display:none !important; }
  .ra-mobiletop{ display:flex !important; }
  .ra-main{ padding-right:0 !important; }
}
`;

/* ---------------------------------- Constants / seed data ---------------------------------- */
const CATEGORIES = ["العناية بالبشرة", "مكياج", "العناية بالشعر", "العطور", "العناية بالجسم", "أدوات ومستلزمات"];

const CATEGORY_THEME = {
  "العناية بالبشرة": { bg: "var(--primary-soft)", fg: "var(--primary-dark)" },
  "مكياج": { bg: "var(--gold-soft)", fg: "#7A5F22" },
  "العناية بالشعر": { bg: "var(--sage-soft)", fg: "var(--sage)" },
  "العطور": { bg: "#E7DEF2", fg: "#5A4380" },
  "العناية بالجسم": { bg: "#FBE4D8", fg: "#9C5A2E" },
  "أدوات ومستلزمات": { bg: "#E4EAF0", fg: "#3F5A73" },
};

const PERMISSION_KEYS = ["addProducts", "editProducts", "deleteProducts", "sellProducts", "viewWholesale", "manageUsers", "manageDatabase"];
const PERMISSION_LABELS = {
  addProducts: "إضافة منتجات",
  editProducts: "تعديل المنتجات",
  deleteProducts: "حذف المنتجات",
  sellProducts: "تسجيل عمليات البيع",
  viewWholesale: "عرض سعر الجملة",
  manageUsers: "إدارة المستخدمين",
  manageDatabase: "إدارة قاعدة البيانات",
};
const ALL_PERMS_TRUE = PERMISSION_KEYS.reduce((a, k) => ({ ...a, [k]: true }), {});
const DEFAULT_EMPLOYEE_PERMS = { addProducts: false, editProducts: true, deleteProducts: false, sellProducts: true, viewWholesale: false, manageUsers: false, manageDatabase: false };

const seedUsers = () => ([
  { id: "u1", name: "سيف السبعاوي", email: "manager@leen.sa", code: "112233", role: "manager", permissions: { ...ALL_PERMS_TRUE } },
  { id: "u2", name: "نور الزهراني", email: "noor@leen.sa", code: "445566", role: "employee", permissions: { ...DEFAULT_EMPLOYEE_PERMS } },
  { id: "u3", name: "ريم القحطاني", email: "reem@leen.sa", code: "778899", role: "employee", permissions: { ...DEFAULT_EMPLOYEE_PERMS, viewWholesale: true } },
]);

const seedProducts = () => ([
  { id: "p1", barcode: "6224000851576", name: "مزيل فيم عصاره", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 3000, wholesale: 2000, stock: 12 },
  { id: "p2", barcode: "6922965176061", name: "مسكاره ايف بيوتي 4D اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 4000, wholesale: 2750, stock: 6 },
  { id: "p3", barcode: "70015", name: "مزيل شمع بارد فيت", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 2500, wholesale: 1750, stock: 6 },
  { id: "p4", barcode: "6291106066890", name: "عطر انا الابيض اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 21750, wholesale: 14500, stock: 2 },
  { id: "p5", barcode: "6291108736203", name: "عطر اجواء احمر اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 23250, wholesale: 15500, stock: 2 },
  { id: "p6", barcode: "شمع1", name: "شمع حبيبات هارد واكس مطاطي", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 4750, wholesale: 3100, stock: 6 },
  { id: "p7", barcode: "5080161850015", name: "شامبو فيتابليكس كرياتين", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 6 },
  { id: "p8", barcode: "5907609356833", name: "كريمهيد مرطب مبيض ايفي لاند اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 6750, wholesale: 4500, stock: 10 },
  { id: "p9", barcode: "5060915671127", name: "واقي شمس UV اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 3750, wholesale: 2500, stock: 4 },
  { id: "p10", barcode: "1645", name: "مزيل شيره حلاوه", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 1500, wholesale: 1000, stock: 12 },
  { id: "p11", barcode: "6290360371047", name: "عطر اكوابورا اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 25500, wholesale: 17000, stock: 2 },
  { id: "p12", barcode: "8682139060517", name: "مزيل شعر ميلانو رولة اخضر", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 2500, wholesale: 1650, stock: 12 },
  { id: "p13", barcode: "6217000058052", name: "مزيل لين علبة", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 750, wholesale: 500, stock: 12 },
  { id: "p14", barcode: "5287000248280", name: "شيره سوفته سكن", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 1000, wholesale: 750, stock: 12 },
  { id: "p15", barcode: "8857101122702", name: "غسول تاج مي بلحليب FOAM", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 3000, wholesale: 2000, stock: 6 },
  { id: "p16", barcode: "5281019026242", name: "مشقر كوزمال وجه", category: "مكياج", photo: "", benefits: [], description: "", retail: 5000, wholesale: 3250, stock: 4 },
  { id: "p17", barcode: "3574661287263", name: "كريم مرطب نايتروجين اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 3 },
  { id: "p18", barcode: "3574661287256", name: "كريم مرطب نايتروجين اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 9750, wholesale: 6500, stock: 3 },
  { id: "p19", barcode: "5011451103948", name: "كريم مرطب تجديد سيمبول", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 6500, wholesale: 4250, stock: 12 },
  { id: "p20", barcode: "5011451103863", name: "غسول وجه سيمبول اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 5500, wholesale: 3750, stock: 12 },
  { id: "p21", barcode: "8691190568924", name: "مثبت مكياج كولدن روز اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 8 },
  { id: "p22", barcode: "3800225902168", name: "غسول رفيولي عصاره اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 7500, wholesale: 5000, stock: 3 },
  { id: "p23", barcode: "6221155130921", name: "شاور جسم لوكس", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 5250, wholesale: 3500, stock: 6 },
  { id: "p24", barcode: "8001459944732", name: "شامبو ومكيف كاندي بيوتي", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 11250, wholesale: 7500, stock: 6 },
  { id: "p25", barcode: "7890886601667", name: "شامبو VS بروتين", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 6 },
  { id: "p26", barcode: "6291107456485", name: "عطر ناو اسود اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 24750, wholesale: 16500, stock: 2 },
  { id: "p27", barcode: "614514990018", name: "عطر كاثرين كبير", category: "العطور", photo: "", benefits: [], description: "", retail: 16500, wholesale: 11000, stock: 2 },
  { id: "p28", barcode: "6290360593685", name: "عطر ناو وردي اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 24750, wholesale: 16500, stock: 2 },
  { id: "p29", barcode: "1451", name: "عطر افيدانس علبه وردي", category: "العطور", photo: "", benefits: [], description: "", retail: 17250, wholesale: 11500, stock: 2 },
  { id: "p30", barcode: "6246817255347", name: "عطر ميلانو نسائي اماراتي اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 13500, wholesale: 9000, stock: 2 },
  { id: "p31", barcode: "6291108321492", name: "عطر بلو شانيل ماركه عالميه", category: "العطور", photo: "", benefits: [], description: "", retail: 18000, wholesale: 12000, stock: 2 },
  { id: "p32", barcode: "8850723749043", name: "غسول وجه هيلتي شوب اعشاب مشكل", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 12 },
  { id: "p33", barcode: "8691091035877", name: "كريم قدم لابيتاك", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 6 },
  { id: "p34", barcode: "5000146055853", name: "مزيل فيت شرائح", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 6500, wholesale: 4250, stock: 12 },
  { id: "p35", barcode: "6291108730515", name: "عطر يارا اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 33750, wholesale: 22500, stock: 2 },
  { id: "p36", barcode: "5000309002755", name: "مزيل فيت عصارة اخضر", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 4000, wholesale: 2600, stock: 12 },
  { id: "p37", barcode: "8999999033156", name: "شامبو لايف بوي بخاخ", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 7500, wholesale: 5000, stock: 6 },
  { id: "p38", barcode: "6001087357050", name: "لوشن جسم فازلين مشكل", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 5250, wholesale: 3500, stock: 6 },
  { id: "p39", barcode: "5080161802038", name: "مكيف بروتين A اصلي", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 8250, wholesale: 5500, stock: 6 },
  { id: "p40", barcode: "6291108323892", name: "عطر L3 ماركه عالميه اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 18000, wholesale: 12000, stock: 2 },
  { id: "p41", barcode: "6290360378213", name: "عطر بلو منك فلور كاردِينا", category: "العطور", photo: "", benefits: [], description: "", retail: 18000, wholesale: 12000, stock: 2 },
  { id: "p42", barcode: "6294015113440", name: "مرطب جسم بخاخ جلسرين", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 4000, wholesale: 2750, stock: 3 },
  { id: "p43", barcode: "6291108528860", name: "عطر فاسيو فرح جديد اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 16500, wholesale: 11000, stock: 4 },
  { id: "p44", barcode: "6294015175479", name: "لوشن كوزمو يوريا اصلي", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 3 },
  { id: "p45", barcode: "8710447223413", name: "شامبو شعر ترسمي ايماراتي", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 6 },
  { id: "p46", barcode: "716524961214", name: "عطر سبليندور اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 22500, wholesale: 15000, stock: 2 },
  { id: "p47", barcode: "6295124001444", name: "عطر جي جي اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 15000, wholesale: 10000, stock: 2 },
  { id: "p48", barcode: "3654335887125", name: "عطر الخيال فخامه جوزي", category: "العطور", photo: "", benefits: [], description: "", retail: 22500, wholesale: 15000, stock: 2 },
  { id: "p49", barcode: "8888202052414", name: "معطر انشانتر روله مشكل", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 3250, wholesale: 2100, stock: 12 },
  { id: "p50", barcode: "8075815092245", name: "حمام معالج مايو سكين لبناني", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 15000, wholesale: 10000, stock: 3 },
  { id: "p51", barcode: "6215731072019", name: "كريم فالز مانع تعرق عصاره", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 2250, wholesale: 1500, stock: 42 },
  { id: "p52", barcode: "6296545050455", name: "عطر كلام نواعم اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 22500, wholesale: 15000, stock: 4 },
  { id: "p53", barcode: "355", name: "كاویه سيت مع مسرح بروتين A", category: "أدوات ومستلزمات", photo: "", benefits: [], description: "", retail: 37500, wholesale: 25000, stock: 2 },
  { id: "p54", barcode: "8690131782740", name: "مثبت مكياج فارماسي بخاخ", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 5000, wholesale: 3250, stock: 4 },
  { id: "p55", barcode: "6953201205832", name: "عود شمع", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 1500, wholesale: 1000, stock: 4 },
  { id: "p56", barcode: "6971398796421", name: "معجون اسنان اطفال ABS", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 1000, wholesale: 750, stock: 6 },
  { id: "p57", barcode: "4015600756758", name: "معجون اسنان كرست مشكل", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 2500, wholesale: 1750, stock: 6 },
  { id: "p58", barcode: "8901030003707", name: "بودرة درة بو نديس، صغير", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 3500, wholesale: 2250, stock: 4 },
  { id: "p59", barcode: "8888202045737", name: "بودرة جسم انشانتر اخضر", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 3500, wholesale: 2250, stock: 12 },
  { id: "p60", barcode: "8886459200169", name: "بودرة جسم ليفينيا", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 4000, wholesale: 2600, stock: 12 },
  { id: "p61", barcode: "8718951291010", name: "معجون اسنان كولكيت اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 2250, wholesale: 1500, stock: 12 },
  { id: "p62", barcode: "6970801430150", name: "منظف اذن قطن تركي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 1000, wholesale: 750, stock: 6 },
  { id: "p63", barcode: "8700216055161", name: "مكينه براون اصلي علبه صغير", category: "أدوات ومستلزمات", photo: "", benefits: [], description: "", retail: 55500, wholesale: 37000, stock: 2 },
  { id: "p64", barcode: "6221155137784", name: "صابون دوف اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 1500, wholesale: 950, stock: 8 },
  { id: "p65", barcode: "3574669909280", name: "صابون طفل جونسن اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 2 },
  { id: "p66", barcode: "8720689031226", name: "مكينه فليبس اصلي جديد", category: "أدوات ومستلزمات", photo: "", benefits: [], description: "", retail: 55500, wholesale: 37000, stock: 2 },
  { id: "p67", barcode: "6295199796061", name: "عطر مو صوف اصلي", category: "العطور", photo: "", benefits: [], description: "", retail: 18750, wholesale: 12500, stock: 4 },
  { id: "p68", barcode: "5011321361089", name: "شامبو هيد اند شولدرز اصلي", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 5500, wholesale: 3750, stock: 12 },
  { id: "p69", barcode: "8075815091026", name: "شامبو+مكيف مايو سكين لبناني", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 15000, wholesale: 10000, stock: 6 },
  { id: "p70", barcode: "8001090153418", name: "بديل باتتين اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 5500, wholesale: 3750, stock: 8 },
  { id: "p71", barcode: "6976154200426", name: "ظل ربوري", category: "مكياج", photo: "", benefits: [], description: "", retail: 5000, wholesale: 3250, stock: 5 },
  { id: "p72", barcode: "8690359018928", name: "عدسه كوكي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 6750, wholesale: 4500, stock: 63 },
  { id: "p73", barcode: "6971312409451", name: "مشط سشوار ايزو 1500 واط", category: "أدوات ومستلزمات", photo: "", benefits: [], description: "", retail: 37500, wholesale: 25000, stock: 2 },
  { id: "p74", barcode: "6973840527263", name: "مشط شسوار موهير وردي H915", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 34500, wholesale: 23000, stock: 2 },
  { id: "p75", barcode: "6971312408485", name: "جهاز خيط اينزو شحن", category: "أدوات ومستلزمات", photo: "", benefits: [], description: "", retail: 16500, wholesale: 11000, stock: 2 },
  { id: "p76", barcode: "6971312404784", name: "مكينه خيط ايزو جديد 6082", category: "أدوات ومستلزمات", photo: "", benefits: [], description: "", retail: 16500, wholesale: 11000, stock: 2 },
  { id: "p77", barcode: "6910206369587", name: "سشوار فليبس 9000", category: "أدوات ومستلزمات", photo: "", benefits: [], description: "", retail: 22500, wholesale: 15000, stock: 2 },
  { id: "p78", barcode: "7623450656189", name: "شامبو شعر براون علبة", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 3 },
  { id: "p79", barcode: "5281019039402", name: "بديل زيت 9 فوائد حجاب", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 5000, wholesale: 3250, stock: 3 },
  { id: "p80", barcode: "8396130018407", name: "معالج مرطب ومغذي شعر بريتي طاسة", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 12000, wholesale: 8000, stock: 2 },
  { id: "p81", barcode: "5281019051923", name: "شاور جسم سوفْت وايف جديد", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 4000, wholesale: 2750, stock: 12 },
  { id: "p82", barcode: "5080161703052", name: "سيروم بروتين A اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 6750, wholesale: 4500, stock: 3 },
  { id: "p83", barcode: "8009331512543", name: "سيروم شعر كولاجين نيترا", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 6750, wholesale: 4500, stock: 3 },
  { id: "p84", barcode: "7890886601711", name: "سيروم شعر VS بروتين", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 6750, wholesale: 4500, stock: 3 },
  { id: "p85", barcode: "8410207100052", name: "زيت جونسن 200 غ اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 4000, wholesale: 2750, stock: 6 },
  { id: "p86", barcode: "5281019037460", name: "مكيف سوف وايف حجاب", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 3750, wholesale: 2500, stock: 6 },
  { id: "p87", barcode: "6926901802007", name: "سيروم شعر مسك قوطي", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 8250, wholesale: 5500, stock: 3 },
  { id: "p88", barcode: "6976635040008", name: "فرشة اسنان دكتور وار 24عدد", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 21000, wholesale: 14000, stock: 1 },
  { id: "p89", barcode: "8001459944817", name: "سيروم كاندي بيوتي اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 9750, wholesale: 6500, stock: 3 },
  { id: "p90", barcode: "8964003408640", name: "كريم عهود ست باكستاني", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 5000, wholesale: 3250, stock: 6 },
  { id: "p91", barcode: "8964003408084", name: "كريم الخلطة عجوبه قهواني", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 5000, wholesale: 3250, stock: 3 },
  { id: "p92", barcode: "8075815091040", name: "سيروم مايو سكين لبناني", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 15000, wholesale: 10000, stock: 3 },
  { id: "p93", barcode: "5280270048222", name: "واقي شمس الورا", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 5000, wholesale: 3250, stock: 3 },
  { id: "p94", barcode: "5281019040606", name: "حمام زيت سوفْت وايف حجاب", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 2 },
  { id: "p95", barcode: "9423", name: "باودر مزيل شعر تايلندي نوفيل", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 5000, wholesale: 3250, stock: 3 },
  { id: "p96", barcode: "3574661656014", name: "كريم مرطب جونسن جديد اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 4250, wholesale: 2900, stock: 3 },
  { id: "p97", barcode: "6954842275796", name: "فرشة اسنان مع دمية اطفال 12 عدد", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 13500, wholesale: 9000, stock: 1 },
  { id: "p98", barcode: "5060453453452", name: "كريم واقي ريفاج UK", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 4000, wholesale: 2750, stock: 3 },
  { id: "p99", barcode: "8683420302095", name: "سبلاش زارا كوزا مشكل شفاف", category: "العطور", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 30 },
  { id: "p100", barcode: "8690604109425", name: "قلم حواجب فلورمار اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 4500, wholesale: 3000, stock: 12 },
  { id: "p101", barcode: "8691190142261", name: "قلم كولدن روز بيجي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 2750, wholesale: 1900, stock: 12 },
  { id: "p102", barcode: "8850723742792", name: "سيروم شعر حراري هيلتي شوب", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 3 },
  { id: "p103", barcode: "028", name: "معجون فور ايفر امريكي اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 8000, wholesale: 5250, stock: 3 },
  { id: "p104", barcode: "8859362507984", name: "صابون حليب الحمار", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 2500, wholesale: 1750, stock: 3 },
  { id: "p105", barcode: "6260227710012", name: "كريم مرطب لليدين J E Y", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 2500, wholesale: 1750, stock: 4 },
  { id: "p106", barcode: "7977", name: "قلم كحل كولدن روز مساحه اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 4750, wholesale: 3200, stock: 6 },
  { id: "p107", barcode: "5280270047744", name: "صابون كوجي اسيد اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 3000, wholesale: 2000, stock: 6 },
  { id: "p108", barcode: "5280270054131", name: "كعب غزال فيكي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 4500, wholesale: 3000, stock: 4 },
  { id: "p109", barcode: "6971877370340", name: "ظل هودا بيوتي 18 لون شفاف", category: "مكياج", photo: "", benefits: [], description: "", retail: 3000, wholesale: 2000, stock: 3 },
  { id: "p110", barcode: "4550516493583", name: "معالج شعر فينو احمر اصلي", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 16500, wholesale: 11000, stock: 2 },
  { id: "p111", barcode: "6971877370487", name: "ظل شفاف وسط 40 لون هوده بيوتي", category: "مكياج", photo: "", benefits: [], description: "", retail: 5250, wholesale: 3500, stock: 3 },
  { id: "p112", barcode: "6922056155234", name: "ظل وسط 32 لون شفاف دياموند بيوتي", category: "مكياج", photo: "", benefits: [], description: "", retail: 4500, wholesale: 3000, stock: 3 },
  { id: "p113", barcode: "6926633698145", name: "قلم ماجك صليب", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 27000, wholesale: 18000, stock: 1 },
  { id: "p114", barcode: "1113", name: "كلينس شرائح شيره دبل", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 2000, wholesale: 1250, stock: 12 },
  { id: "p115", barcode: "6214005510486", name: "قلم حواجب بروتو اصلي 12 عدد", category: "مكياج", photo: "", benefits: [], description: "", retail: 23250, wholesale: 15500, stock: 1 },
  { id: "p116", barcode: "6979865090171", name: "ظل ريبوري مات 18 الوان", category: "مكياج", photo: "", benefits: [], description: "", retail: 5500, wholesale: 3750, stock: 4 },
  { id: "p117", barcode: "6975115210283", name: "ظل بينك كي 30 الوان", category: "مكياج", photo: "", benefits: [], description: "", retail: 5250, wholesale: 3500, stock: 2 },
  { id: "p118", barcode: "6962822583601", name: "ظل رومانتيك برايت 54 لون", category: "مكياج", photo: "", benefits: [], description: "", retail: 5250, wholesale: 3500, stock: 3 },
  { id: "p119", barcode: "8682109085786", name: "اسيتون كلينس فرفشه 24 عدد", category: "أدوات ومستلزمات", photo: "", benefits: [], description: "", retail: 28500, wholesale: 19000, stock: 1 },
  { id: "p120", barcode: "8683420300725", name: "سبلاش زارا كويزا جديد", category: "العطور", photo: "", benefits: [], description: "", retail: 5000, wholesale: 3250, stock: 8 },
  { id: "p121", barcode: "110", name: "جهاز شمع رول ميلانو", category: "أدوات ومستلزمات", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 2 },
  { id: "p122", barcode: "3700082500425", name: "معطر شالس اصلي", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 3750, wholesale: 2500, stock: 6 },
  { id: "p123", barcode: "6291109865742", name: "سبلاش مع عطر شعر بليسس كار", category: "العطور", photo: "", benefits: [], description: "", retail: 12750, wholesale: 8500, stock: 8 },
  { id: "p124", barcode: "8690587001952", name: "معطر سالنجر", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 4000, wholesale: 2600, stock: 18 },
  { id: "p125", barcode: "8680923345093", name: "غسول وجه دكتور كلينك بخاخ", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 13000, wholesale: 8750, stock: 12 },
  { id: "p126", barcode: "4901872471997", name: "سيروم فينو كوري اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 19500, wholesale: 13000, stock: 2 },
  { id: "p127", barcode: "8680923336343", name: "كريم وجه دكتور كلينك بريبيوتيك حيوي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 15750, wholesale: 10500, stock: 12 },
  { id: "p128", barcode: "8809416470184", name: "سيروم وجه كوسركس هایلوريك اسيد", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 21000, wholesale: 14000, stock: 2 },
  { id: "p129", barcode: "8809416470009", name: "سيروم وجه كوسركس اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 19500, wholesale: 13000, stock: 2 },
  { id: "p130", barcode: "8680923353081", name: "واقي شمس د كلينك بشره دهني", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 12750, wholesale: 8500, stock: 6 },
  { id: "p131", barcode: "8809416470122", name: "كريم وجه هایلوريك اسيد كوسركس", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 22500, wholesale: 15000, stock: 2 },
  { id: "p132", barcode: "8809416470016", name: "كريم مرطب كوسركس حلزون اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 21000, wholesale: 14000, stock: 2 },
  { id: "p133", barcode: "6954125472317", name: "جهاز شمع جلاتين صغير", category: "أدوات ومستلزمات", photo: "", benefits: [], description: "", retail: 7500, wholesale: 5000, stock: 2 },
  { id: "p134", barcode: "8999777017873", name: "معطر روله نيفيا اصلي", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 3000, wholesale: 2000, stock: 10 },
  { id: "p135", barcode: "8690131130756", name: "معطر روله فارمسي اصلي", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 3750, wholesale: 2500, stock: 24 },
  { id: "p136", barcode: "6158506068452", name: "معطر خليجي مشكل اصلي", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 3500, wholesale: 2250, stock: 88 },
  { id: "p137", barcode: "8717163004869", name: "معطر دوف بخاخ كبير", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 5250, wholesale: 3500, stock: 36 },
  { id: "p138", barcode: "3574661499666", name: "غسول نايتروجين عصاره", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 7000, wholesale: 4750, stock: 3 },
  { id: "p139", barcode: "3574661499321", name: "غسول ناتروجين اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 6500, wholesale: 4250, stock: 2 },
  { id: "p140", barcode: "725272732267", name: "برايمر حلازوني مع واقي اصلي M", category: "مكياج", photo: "", benefits: [], description: "", retail: 20250, wholesale: 13500, stock: 2 },
  { id: "p141", barcode: "8886304600120", name: "معطر رجالي مشكل اصلي", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 5000, wholesale: 3250, stock: 24 },
  { id: "p142", barcode: "8682536445832", name: "بودره فلورمار كومباك مربع", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 8250, wholesale: 5500, stock: 9 },
  { id: "p143", barcode: "8682536470933", name: "لوس باودر فلورمان اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 9500, wholesale: 6250, stock: 9 },
  { id: "p144", barcode: "8850723749876", name: "جل ماني مرطب للوجه هيلتي شوب", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 13500, wholesale: 9000, stock: 2 },
  { id: "p145", barcode: "6932511230000", name: "كريم مغذي فيتامين سي ADS", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 4 },
  { id: "p146", barcode: "6953029037219", name: "مرطب بشره الورا مربع سي+هایلوريك اسيد", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 6 },
  { id: "p147", barcode: "8397323936553", name: "مشقر وجه بريتي ايطالي", category: "مكياج", photo: "", benefits: [], description: "", retail: 2250, wholesale: 1500, stock: 4 },
  { id: "p148", barcode: "5060565106574", name: "واقي شمس ريفيولا اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 14250, wholesale: 9500, stock: 6 },
  { id: "p149", barcode: "6291108521809", name: "عطر مودا اس ماي ادول جديد", category: "العطور", photo: "", benefits: [], description: "", retail: 13500, wholesale: 9000, stock: 2 },
  { id: "p150", barcode: "4033651360618", name: "مسكاره بيو اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 14250, wholesale: 9500, stock: 3 },
  { id: "p151", barcode: "5901801604211", name: "مسكاره بومه اسود اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 8250, wholesale: 5500, stock: 3 },
  { id: "p152", barcode: "3390889745503", name: "عطر ليدي سكسي", category: "العطور", photo: "", benefits: [], description: "", retail: 13500, wholesale: 9000, stock: 2 },
  { id: "p153", barcode: "8809576261646", name: "مرطب وجه سنتيلا جوزي مهدي الوجه", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 24000, wholesale: 16000, stock: 2 },
  { id: "p154", barcode: "8809576261493", name: "كريم سنتيلا ازرق مرطب مهدي بشرة", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 24000, wholesale: 16000, stock: 2 },
  { id: "p155", barcode: "8809576261172", name: "سيروم تون سنتيلا تفتيح بشره", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 24000, wholesale: 16000, stock: 2 },
  { id: "p156", barcode: "8809576261486", name: "سيروم سنتيلا ازرق هايلوريك اسيد", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 26250, wholesale: 17500, stock: 2 },
  { id: "p157", barcode: "8809576261462", name: "سيروم سنتيلا مقلص مسام وردي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 24000, wholesale: 16000, stock: 2 },
  { id: "p158", barcode: "8809576261653", name: "غسول عصاره فووم وردي سنتيلا", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 19500, wholesale: 13000, stock: 2 },
  { id: "p159", barcode: "5900717317338", name: "واقي شمس لارین اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 12750, wholesale: 8500, stock: 3 },
  { id: "p160", barcode: "8850723749098", name: "كريم وجه تفتيح وتوحيد لون البشره هيلتي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 11250, wholesale: 7500, stock: 2 },
  { id: "p161", barcode: "8809562192121", name: "واقي شمس ارينسيا حساس", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 21000, wholesale: 14000, stock: 2 },
  { id: "p162", barcode: "8809875906477", name: "سيروم فيتامين سي عصاره بيوتي اوف", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 21750, wholesale: 14500, stock: 3 },
  { id: "p163", barcode: "8809738316146", name: "كريم حول العين بيوتي او جونسن عصاره", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 21750, wholesale: 14500, stock: 3 },
  { id: "p164", barcode: "8800256114665", name: "تونر باك منصف وجه ميدي كاب اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 30000, wholesale: 20000, stock: 2 },
  { id: "p165", barcode: "8809782555508", name: "واقي شمس بيوتي او جونسن عصاره", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 21750, wholesale: 14500, stock: 6 },
  { id: "p166", barcode: "8800256119134", name: "سيروم ميدي كاب وردي نيسا ميد 15%", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 25500, wholesale: 17000, stock: 2 },
  { id: "p167", barcode: "8800256115549", name: "سيروم كولاجين ميدي كاب شوت 7500", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 27750, wholesale: 18500, stock: 2 },
  { id: "p168", barcode: "8800256108053", name: "سيروم وجه ميدي كوب كوري اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 25500, wholesale: 17000, stock: 2 },
  { id: "p169", barcode: "3760245850712", name: "عصاره A313 تسبغات مبيض اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 28500, wholesale: 19000, stock: 2 },
  { id: "p170", barcode: "8809700320812", name: "كريم ريتينول شوت عصاره تجاعيد اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 19500, wholesale: 13000, stock: 3 },
  { id: "p171", barcode: "8800289467714", name: "كريم مرطب كولاجين مي دي كاب كوري", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 30000, wholesale: 20000, stock: 2 },
  { id: "p172", barcode: "8809982769866", name: "كريم مرطب ميدي كوب جوزي فيتامين سي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 33750, wholesale: 22500, stock: 2 },
  { id: "p173", barcode: "8800256119660", name: "كريم مرطب ميدي كاب نيساميد 5%", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 33000, wholesale: 22000, stock: 2 },
  { id: "p174", barcode: "3600542446198", name: "غسول جل منقي غارنيه اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 9750, wholesale: 6500, stock: 3 },
  { id: "p175", barcode: "8680923349466", name: "مانع تعرق رول دكتور كلينك", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 7500, wholesale: 5000, stock: 18 },
  { id: "p176", barcode: "5059018504265", name: "سيروم شعر اطفال حراري افون", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 3 },
  { id: "p177", barcode: "3600541729711", name: "مزيل مكياج كارنر وردي اصلي", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 3 },
  { id: "p178", barcode: "3600541897694", name: "مزيل مكياج كارنر اصلي زيتي لوتين", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 9750, wholesale: 6500, stock: 4 },
  { id: "p179", barcode: "3600542368094", name: "مزيل مكياج كارنر اصفر اصلي", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 1 },
  { id: "p180", barcode: "5285001272372", name: "مزيل مكياج مايو سكین لبناني", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 6750, wholesale: 4500, stock: 6 },
  { id: "p181", barcode: "5060565105447", name: "لوشن عصاره رفيولي بشرة جافه اصلي", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 11250, wholesale: 7500, stock: 3 },
  { id: "p182", barcode: "8809640734427", name: "غسول انوا فووم عصاره", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 18000, wholesale: 12000, stock: 2 },
  { id: "p183", barcode: "5060565105430", name: "لوشن رفيولي بشرة جافه بخاخ اصلي", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 13000, wholesale: 8750, stock: 3 },
  { id: "p184", barcode: "8809640737190", name: "سيروم انوا اخضر ازاليك اسيد+هايلوينك", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 30000, wholesale: 20000, stock: 2 },
  { id: "p185", barcode: "8809640734526", name: "سيروم انوا للبشره بل نياساميد اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 27750, wholesale: 18500, stock: 2 },
  { id: "p186", barcode: "8809686383566", name: "مر طب حل بشرة دهنية أزيلك", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 22500, wholesale: 15000, stock: 2 },
  { id: "p187", barcode: "8809576261622", name: "واقي شمس سنتيلا ابيض اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 22500, wholesale: 15000, stock: 3 },
  { id: "p188", barcode: "8809576261592", name: "واقي شمس سنتيلا عصاره", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 22500, wholesale: 15000, stock: 1 },
  { id: "p189", barcode: "4006000017358", name: "عصاره يوسرين مناطق حساسه اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 48000, wholesale: 32000, stock: 2 },
  { id: "p190", barcode: "8809416470191", name: "واقي شمس كوسريكس اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 16500, wholesale: 11000, stock: 3 },
  { id: "p191", barcode: "769915190977", name: "تونر اوردنري اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 26250, wholesale: 17500, stock: 2 },
  { id: "p192", barcode: "9314839020766", name: "كريم مرطب وجه كيو في اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 22500, wholesale: 15000, stock: 2 },
  { id: "p193", barcode: "769915190311", name: "سيروم اوردينري زنك اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 19500, wholesale: 13000, stock: 4 },
  { id: "p194", barcode: "8691190514556", name: "جل حواجب كولدن روز تركي اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 6750, wholesale: 4500, stock: 4 },
  { id: "p195", barcode: "3337875816809", name: "كريم لاروش ترميم او اصلاح البشره", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 22500, wholesale: 15000, stock: 3 },
  { id: "p196", barcode: "8809447256221", name: "عصاره دكتور الثيا 345 اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 29250, wholesale: 19500, stock: 4 },
  { id: "p197", barcode: "6214005553438", name: "اساس بروتو ذهبي اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 8250, wholesale: 5500, stock: 4 },
  { id: "p198", barcode: "3760237854094", name: "بودره نوط اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 12000, wholesale: 8000, stock: 9 },
  { id: "p199", barcode: "3701365774748", name: "اساس نوط اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 12000, wholesale: 8000, stock: 9 },
  { id: "p200", barcode: "8859362507991", name: "غسول وجة حليب حمار", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 3250, wholesale: 2100, stock: 6 },
  { id: "p201", barcode: "8691190568115", name: "اساس تيوب cc كولن روز اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 8250, wholesale: 5500, stock: 6 },
  { id: "p202", barcode: "052336341456", name: "جل حاجب كوتوبي صغير اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 7500, wholesale: 5000, stock: 6 },
  { id: "p203", barcode: "4059729281975", name: "كونسيلر كاتريس اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 10500, wholesale: 7000, stock: 6 },
  { id: "p204", barcode: "4250587739084", name: "مسكاره اسينس اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 5500, wholesale: 3750, stock: 6 },
  { id: "p205", barcode: "3616303397319", name: "اساس برجواس زجاجي اصلي جديد", category: "مكياج", photo: "", benefits: [], description: "", retail: 13500, wholesale: 9000, stock: 9 },
  { id: "p206", barcode: "8690131764005", name: "اساس فارماسي عصاره CC + BB", category: "مكياج", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 12 },
  { id: "p207", barcode: "4251232221619", name: "مسكاره اسنس اميرات اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 7000, wholesale: 4750, stock: 12 },
  { id: "p208", barcode: "3800225902175", name: "غسول رفيولي عصاره اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 7500, wholesale: 5000, stock: 6 },
  { id: "p209", barcode: "3600531324506", name: "اساس فت مي عصاره اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 12000, wholesale: 8000, stock: 4 },
  { id: "p210", barcode: "8690604558209", name: "كونسيلر فلورمار اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 6 },
  { id: "p211", barcode: "8690131780494", name: "جل حاجب فارماسي اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 2 },
  { id: "p212", barcode: "8691190741020", name: "بودره كولدن روز اصلي", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 8250, wholesale: 5500, stock: 4 },
  { id: "p213", barcode: "4250947598283", name: "اساس كاترس قطره اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 15000, wholesale: 10000, stock: 4 },
  { id: "p214", barcode: "8690131129866", name: "مسكاره فارماسي فضي اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 9000, wholesale: 6000, stock: 3 },
  { id: "p215", barcode: "3616303915100", name: "باودر برجواس اصلي", category: "مكياج", photo: "", benefits: [], description: "", retail: 15000, wholesale: 10000, stock: 6 },
  { id: "p216", barcode: "كو", name: "صبغ كولاجين نيترو", category: "العناية بالشعر", photo: "", benefits: [], description: "", retail: 6000, wholesale: 4000, stock: 138 },
  { id: "p217", barcode: "راژكو", name: "مزيل شعر بودره رازكو 20 سيت داخل", category: "العناية بالجسم", photo: "", benefits: [], description: "", retail: 28500, wholesale: 19000, stock: 1 },
  { id: "p218", barcode: "1329", name: "ساتتيء او لم انز تاك 7*16", category: "العناية بالبشرة", photo: "", benefits: [], description: "", retail: 22500, wholesale: 15000, stock: 1 },
]);

const uid = () => Math.random().toString(36).slice(2, 10);
const genBarcode = () => "628" + Math.floor(1000000000 + Math.random() * 8999999999).toString().slice(0, 10);
const fmtPrice = (n) => `${Math.round(Number(n || 0)).toLocaleString("ar-IQ")} د.ع`;
const nowStamp = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}_${String(d.getHours()).padStart(2, "0")}${String(d.getMinutes()).padStart(2, "0")}`;
};

/* ---------------------------------- Small shared components ---------------------------------- */
function ProductPhoto({ product, size = 64, rounded = 16 }) {
  const [broken, setBroken] = useState(false);
  const theme = CATEGORY_THEME[product?.category] || CATEGORY_THEME["مكياج"];
  if (product?.photo && !broken) {
    return (
      <img
        src={product.photo}
        onError={() => setBroken(true)}
        alt={product.name}
        style={{ width: size, height: size, objectFit: "cover", borderRadius: rounded, border: "1px solid var(--line)" }}
      />
    );
  }
  return (
    <div style={{
      width: size, height: size, borderRadius: rounded, background: theme.bg,
      display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, border: "1px solid var(--line)"
    }}>
      <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 24 24" fill="none" stroke={theme.fg} strokeWidth="1.6">
        <path d="M9 2h6v3.2c1.6.7 2.6 2.2 2.6 4V20a2 2 0 0 1-2 2H8.4a2 2 0 0 1-2-2V9.2c0-1.8 1-3.3 2.6-4V2z" />
        <path d="M8 12h8" />
      </svg>
    </div>
  );
}

function Badge({ children, bg, fg, icon: Icon }) {
  return (
    <span className="ra-badge" style={{ background: bg, color: fg }}>
      {Icon && <Icon size={12} />}
      {children}
    </span>
  );
}

function Toggle({ on, onClick, disabled }) {
  return (
    <button type="button" disabled={disabled} onClick={onClick} className={`ra-toggle ${on ? "on" : "off"}`} style={disabled ? { opacity: .5, cursor: "not-allowed" } : {}}>
      <span />
    </button>
  );
}

function Toast({ toasts }) {
  return (
    <div style={{ position: "fixed", bottom: 20, insetInlineEnd: 20, zIndex: 200, display: "flex", flexDirection: "column", gap: 10 }}>
      {toasts.map(t => (
        <div key={t.id} className="ra-pop" style={{
          display: "flex", alignItems: "center", gap: 10, padding: "12px 16px", borderRadius: 12,
          background: t.type === "error" ? "var(--danger)" : t.type === "warn" ? "var(--gold)" : "var(--primary)",
          color: "#fff", boxShadow: "var(--shadow)", fontWeight: 700, fontSize: 14, minWidth: 220
        }}>
          {t.type === "error" ? <AlertTriangle size={17} /> : <Check size={17} />}
          {t.msg}
        </div>
      ))}
    </div>
  );
}

function ConfirmModal({ data, onClose }) {
  if (!data) return null;
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(46,35,32,0.45)", zIndex: 300, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }} onClick={onClose}>
      <div className="ra-card ra-pop" style={{ maxWidth: 400, width: "100%", padding: 26 }} onClick={e => e.stopPropagation()}>
        <div style={{
          width: 46, height: 46, borderRadius: 13, background: data.danger ? "var(--danger-soft)" : "var(--gold-soft)",
          display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 14
        }}>
          <TriangleAlert size={22} color={data.danger ? "var(--danger)" : "var(--gold)"} />
        </div>
        <h3 style={{ fontSize: 18, fontWeight: 800, margin: "0 0 8px" }}>{data.title}</h3>
        <p style={{ fontSize: 14, color: "var(--ink-soft)", lineHeight: 1.7, margin: "0 0 20px" }}>{data.message}</p>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="ra-btn ra-btn-ghost" style={{ flex: 1 }} onClick={onClose}>إلغاء</button>
          <button className={`ra-btn ${data.danger ? "ra-btn-danger" : "ra-btn-primary"}`} style={{ flex: 1 }} onClick={() => { data.onConfirm(); onClose(); }}>
            {data.confirmLabel || "تأكيد"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Camera Barcode Scanner ---------------------------------- */
function CameraScanModal({ onClose, onDetect }) {
  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const rafRef = useRef(null);
  const [status, setStatus] = useState("starting"); // starting | ready | unsupported | denied
  const [manualCode, setManualCode] = useState("");

  useEffect(() => {
    let cancelled = false;
    const start = async () => {
      const supported = "BarcodeDetector" in window;
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        if (supported) {
          setStatus("ready");
          let detector;
          try { detector = new window.BarcodeDetector({ formats: ["ean_13", "ean_8", "upc_a", "upc_e", "code_128", "code_39", "codabar", "itf"] }); }
          catch { detector = new window.BarcodeDetector(); }
          const tick = async () => {
            if (cancelled) return;
            try {
              const codes = await detector.detect(videoRef.current);
              if (codes && codes.length > 0) { onDetect(codes[0].rawValue); return; }
            } catch { /* transient decode miss, keep scanning */ }
            rafRef.current = requestAnimationFrame(tick);
          };
          rafRef.current = requestAnimationFrame(tick);
        } else {
          setStatus("unsupported");
        }
      } catch {
        if (!cancelled) setStatus("denied");
      }
    };
    start();
    return () => {
      cancelled = true;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    };
  }, [onDetect]);

  const submitManual = (e) => {
    e.preventDefault();
    if (manualCode.trim()) onDetect(manualCode.trim());
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(20,14,12,0.82)", zIndex: 320, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }} onClick={onClose}>
      <div className="ra-card ra-pop" style={{ width: "100%", maxWidth: 440, padding: 20 }} onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <h3 style={{ fontSize: 16, fontWeight: 800, margin: 0 }}>مسح الباركود بكاميرا الجهاز</h3>
          <button type="button" className="ra-icon-btn" onClick={onClose}><X size={17} /></button>
        </div>

        <div style={{ position: "relative", borderRadius: 14, overflow: "hidden", background: "#141010", aspectRatio: "4 / 3" }}>
          <video ref={videoRef} muted playsInline style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          {status === "ready" && (
            <div style={{ position: "absolute", inset: "18% 12%", border: "2px solid var(--gold)", borderRadius: 10, boxShadow: "0 0 0 999px rgba(0,0,0,0.35)", pointerEvents: "none" }} />
          )}
          {status === "starting" && (
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 13, fontWeight: 700 }}>
              جارٍ تشغيل الكاميرا…
            </div>
          )}
        </div>

        {status === "denied" && (
          <p style={{ fontSize: 13, color: "var(--danger)", textAlign: "center", marginTop: 12 }}>تعذّر الوصول إلى الكاميرا. يرجى السماح بإذن الكاميرا من إعدادات المتصفح ثم إعادة المحاولة.</p>
        )}
        {status === "unsupported" && (
          <p style={{ fontSize: 13, color: "var(--ink-soft)", textAlign: "center", marginTop: 12 }}>هذا المتصفح لا يدعم القراءة التلقائية للباركود (يعمل بأفضل شكل على Chrome أو Edge). استخدم الإدخال اليدوي بالأسفل.</p>
        )}
        {status === "ready" && (
          <p style={{ fontSize: 12.5, color: "var(--ink-mute)", textAlign: "center", marginTop: 10 }}>وجّه الكاميرا نحو الباركود داخل الإطار الذهبي</p>
        )}

        <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
          <input className="ra-input" placeholder="أو أدخل الرمز يدوياً" value={manualCode}
            onChange={e => setManualCode(e.target.value)} onKeyDown={e => { if (e.key === "Enter") submitManual(e); }} />
          <button type="button" className="ra-btn ra-btn-gold" onClick={submitManual}>بحث</button>
        </div>
      </div>
    </div>
  );
}


function LoginScreen({ users, onLogin, pushToast }) {
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [showCode, setShowCode] = useState(false);
  const [shake, setShake] = useState(false);

  // Normalize aggressively: trim, collapse invisible/zero-width chars, case-insensitive email,
  // digits-only comparison for the code so stray spaces or Arabic-Indic digits never block login.
  const clean = (s) => String(s || "").replace(/[\u200B-\u200F\u202A-\u202E\uFEFF]/g, "").trim();
  const toAsciiDigits = (s) => clean(s).replace(/[٠-٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d));

  const submit = (e) => {
    e.preventDefault();
    const emailIn = clean(email).toLowerCase();
    const codeIn = toAsciiDigits(code);
    const match = users.find(u => clean(u.email).toLowerCase() === emailIn && toAsciiDigits(u.code) === codeIn);
    if (match) {
      onLogin(match);
    } else {
      setShake(true);
      pushToast("البريد الإلكتروني أو رمز الدخول غير صحيح", "error");
      setTimeout(() => setShake(false), 420);
    }
  };

  const manager = users.find(u => u.role === "manager");
  const employee = users.find(u => u.role === "employee");

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 20, background: "radial-gradient(circle at 30% 20%, var(--primary-soft), var(--bg) 60%)" }}>
      <div className={`ra-card ra-fade-in ${shake ? "ra-shake" : ""}`} style={{ width: "100%", maxWidth: 400, padding: "38px 32px" }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginBottom: 26 }}>
          <div style={{ width: 58, height: 58, borderRadius: 18, background: "var(--primary)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 14, boxShadow: "var(--shadow)" }}>
            <Sparkles size={26} color="#fff" />
          </div>
          <h1 className="ra-serif" style={{ fontSize: 32, fontWeight: 700, margin: 0, color: "var(--primary-dark)" }}>لين</h1>
          <p style={{ fontSize: 13.5, color: "var(--ink-mute)", marginTop: 4 }}>نظام إدارة متجر مستحضرات التجميل</p>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div>
            <label className="ra-label">البريد الإلكتروني</label>
            <div style={{ position: "relative" }}>
              <Mail size={17} style={{ position: "absolute", top: 12, insetInlineStart: 13, color: "var(--ink-mute)" }} />
              <input className="ra-input" style={{ paddingInlineStart: 38 }} type="email" placeholder="name@leen.sa" autoCapitalize="off" autoCorrect="off"
                value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => { if (e.key === "Enter") submit(e); }} />
            </div>
          </div>
          <div>
            <label className="ra-label">رمز الدخول</label>
            <div style={{ position: "relative" }}>
              <KeyRound size={17} style={{ position: "absolute", top: 12, insetInlineStart: 13, color: "var(--ink-mute)" }} />
              <input className="ra-input" style={{ paddingInlineStart: 38, paddingInlineEnd: 38, letterSpacing: 3 }}
                type={showCode ? "text" : "password"} placeholder="••••••" value={code} onChange={e => setCode(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter") submit(e); }} />
              <button type="button" onClick={() => setShowCode(s => !s)} style={{ position: "absolute", top: 10, insetInlineEnd: 10, background: "none", border: "none", cursor: "pointer", color: "var(--ink-mute)" }}>
                {showCode ? <EyeOff size={17} /> : <Eye size={17} />}
              </button>
            </div>
          </div>
          <button type="button" className="ra-btn ra-btn-primary" style={{ marginTop: 6, padding: "12px 18px" }} onClick={submit}>
            تسجيل الدخول <ChevronLeft size={16} />
          </button>
        </div>

        <div className="ra-hairline" style={{ marginTop: 22, paddingTop: 16 }}>
          <p style={{ fontSize: 11, color: "var(--ink-mute)", textAlign: "center", lineHeight: 1.8, margin: 0 }}>
            حساب المدير التجريبي: {manager?.email} — {manager?.code}<br />
            حساب الموظف التجريبي: {employee?.email} — {employee?.code}
          </p>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Shell: Sidebar + Topbar ---------------------------------- */
function NavItems({ can, screen, go, isManager }) {
  const items = [
    { key: "dashboard", label: "لوحة التحكم", icon: LayoutDashboard, show: true },
    { key: "products", label: "المنتجات", icon: Package, show: true },
    { key: "sales", label: "المبيعات", icon: ShoppingBag, show: can("sellProducts") },
    { key: "users", label: "المستخدمون", icon: Users, show: can("manageUsers") },
    { key: "database", label: "قاعدة البيانات", icon: Database, show: can("manageDatabase") },
  ];
  return items.filter(i => i.show).map(i => (
    <div key={i.key} className={`ra-nav-item ${screen === i.key ? "active" : ""}`} onClick={() => go(i.key)}>
      <i.icon size={18} /> {i.label}
    </div>
  ));
}

function Sidebar({ user, screen, go, can, onLogout }) {
  return (
    <aside className="ra-sidebar" style={{
      width: 240, flexShrink: 0, position: "fixed", top: 0, bottom: 0, insetInlineEnd: 0,
      background: "var(--surface)", borderInlineStart: "1px solid var(--line)", padding: 20,
      display: "flex", flexDirection: "column", zIndex: 20
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 28, padding: "0 4px" }}>
        <div style={{ width: 38, height: 38, borderRadius: 11, background: "var(--primary)", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Sparkles size={18} color="#fff" />
        </div>
        <div>
          <div className="ra-serif" style={{ fontWeight: 700, fontSize: 19, color: "var(--primary-dark)", lineHeight: 1 }}>لين</div>
          <div style={{ fontSize: 11, color: "var(--ink-mute)" }}>إدارة المتجر</div>
        </div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        <NavItems can={can} screen={screen} go={go} />
      </div>

      <div style={{ marginTop: "auto" }}>
        <div className="ra-hairline" style={{ paddingTop: 14, marginBottom: 12, display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10, background: "var(--primary-soft)", color: "var(--primary-dark)",
            display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 14, flexShrink: 0
          }}>
            {user.name.trim().charAt(0)}
          </div>
          <div style={{ overflow: "hidden" }}>
            <div style={{ fontWeight: 700, fontSize: 13.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{user.name}</div>
            <Badge bg={user.role === "manager" ? "var(--gold-soft)" : "var(--sage-soft)"} fg={user.role === "manager" ? "#7A5F22" : "var(--sage)"}>
              {user.role === "manager" ? "مدير" : "موظف"}
            </Badge>
          </div>
        </div>
        <button className="ra-btn ra-btn-ghost" style={{ width: "100%" }} onClick={onLogout}>
          <LogOut size={16} /> تسجيل الخروج
        </button>
      </div>
    </aside>
  );
}

function MobileTop({ user, onMenu, title }) {
  return (
    <div className="ra-mobiletop" style={{
      display: "none", alignItems: "center", justifyContent: "space-between", padding: "14px 16px",
      background: "var(--surface)", borderBottom: "1px solid var(--line)", position: "sticky", top: 0, zIndex: 15
    }}>
      <button className="ra-icon-btn" onClick={onMenu}><Menu size={19} /></button>
      <div style={{ fontWeight: 800, fontSize: 15.5 }}>{title}</div>
      <div style={{
        width: 34, height: 34, borderRadius: 9, background: "var(--primary-soft)", color: "var(--primary-dark)",
        display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: 13
      }}>{user.name.trim().charAt(0)}</div>
    </div>
  );
}

function MobileDrawer({ open, onClose, user, screen, go, can, onLogout }) {
  if (!open) return null;
  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 250, display: "flex" }}>
      <div style={{ flex: 1, background: "rgba(46,35,32,.4)" }} onClick={onClose} />
      <div className="ra-pop" style={{ width: 260, background: "var(--surface)", padding: 20, display: "flex", flexDirection: "column" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 22 }}>
          <div className="ra-serif" style={{ fontWeight: 700, fontSize: 20, color: "var(--primary-dark)" }}>لين</div>
          <button className="ra-icon-btn" onClick={onClose}><X size={17} /></button>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
          <NavItems can={can} screen={screen} go={(k) => { go(k); onClose(); }} />
        </div>
        <button className="ra-btn ra-btn-ghost" style={{ marginTop: "auto" }} onClick={onLogout}>
          <LogOut size={16} /> تسجيل الخروج
        </button>
      </div>
    </div>
  );
}

/* ---------------------------------- Dashboard ---------------------------------- */
function StatCard({ icon: Icon, label, value, bg, fg }) {
  return (
    <div className="ra-card ra-fade-in" style={{ padding: 20, display: "flex", alignItems: "center", gap: 14 }}>
      <div style={{ width: 46, height: 46, borderRadius: 13, background: bg, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <Icon size={21} color={fg} />
      </div>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 12.5, color: "var(--ink-mute)", fontWeight: 700 }}>{label}</div>
        <div style={{ fontSize: 21, fontWeight: 800, marginTop: 2, whiteSpace: "nowrap" }}>{value}</div>
      </div>
    </div>
  );
}

function DashboardScreen({ products, users, user, can, go }) {
  const lowStock = products.filter(p => p.stock <= 5);
  const totalWholesale = products.reduce((s, p) => s + p.wholesale * p.stock, 0);
  const totalRetail = products.reduce((s, p) => s + p.retail * p.stock, 0);

  return (
    <div className="ra-fade-in">
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 23, fontWeight: 800, margin: 0 }}>مرحباً، {user.name.split(" ")[0]} ✨</h1>
        <p style={{ color: "var(--ink-mute)", fontSize: 14, marginTop: 4 }}>نظرة سريعة على أداء المتجر اليوم</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14, marginBottom: 24 }}>
        <StatCard icon={Package} label="إجمالي المنتجات" value={products.length} bg="var(--primary-soft)" fg="var(--primary-dark)" />
        <StatCard icon={Boxes} label="إجمالي الكمية بالمخزون" value={products.reduce((s, p) => s + p.stock, 0)} bg="var(--sage-soft)" fg="var(--sage)" />
        {can("viewWholesale") && <StatCard icon={Wallet} label="قيمة المخزون (جملة)" value={fmtPrice(totalWholesale)} bg="var(--gold-soft)" fg="#7A5F22" />}
        <StatCard icon={TriangleAlert} label="منتجات منخفضة المخزون" value={lowStock.length} bg="var(--danger-soft)" fg="var(--danger)" />
        {can("manageUsers") && <StatCard icon={Users} label="عدد المستخدمين" value={users.length} bg="#E4EAF0" fg="#3F5A73" />}
        {!can("viewWholesale") && <StatCard icon={Wallet} label="قيمة المخزون (تجزئة)" value={fmtPrice(totalRetail)} bg="var(--gold-soft)" fg="#7A5F22" />}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }} className="ra-dash-grid">
        <div className="ra-card" style={{ padding: 20 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
            <h3 style={{ fontSize: 16, fontWeight: 800, margin: 0 }}>منتجات بحاجة لإعادة تعبئة</h3>
            <button className="ra-btn ra-btn-ghost ra-btn-sm" onClick={() => go("products")}>عرض الكل</button>
          </div>
          {lowStock.length === 0 ? (
            <p style={{ color: "var(--ink-mute)", fontSize: 14 }}>لا توجد منتجات منخفضة المخزون حالياً 🎉</p>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {lowStock.slice(0, 5).map(p => (
                <div key={p.id} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <ProductPhoto product={p} size={42} rounded={11} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 13.5, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.name}</div>
                    <div style={{ fontSize: 12, color: "var(--ink-mute)" }}>{p.barcode}</div>
                  </div>
                  <Badge bg="var(--danger-soft)" fg="var(--danger)">{p.stock} متبقي</Badge>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="ra-card" style={{ padding: 20 }}>
          <h3 style={{ fontSize: 16, fontWeight: 800, margin: "0 0 14px" }}>إجراءات سريعة</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <button className="ra-btn ra-btn-primary" style={{ justifyContent: "flex-start" }} onClick={() => go("products")}>
              <ScanBarcode size={17} /> البحث عن منتج
            </button>
            {can("addProducts") && (
              <button className="ra-btn ra-btn-gold" style={{ justifyContent: "flex-start" }} onClick={() => go("products", { openAdd: true })}>
                <Plus size={17} /> إضافة منتج جديد
              </button>
            )}
            {can("manageUsers") && (
              <button className="ra-btn ra-btn-ghost" style={{ justifyContent: "flex-start" }} onClick={() => go("users")}>
                <UserPlus size={17} /> إدارة المستخدمين
              </button>
            )}
            {can("manageDatabase") && (
              <button className="ra-btn ra-btn-ghost" style={{ justifyContent: "flex-start" }} onClick={() => go("database")}>
                <Database size={17} /> النسخ الاحتياطي وقاعدة البيانات
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Sales Screen ---------------------------------- */
function SalesScreen({ sales }) {
  const totalRevenue = sales.reduce((s, r) => s + r.price, 0);
  return (
    <div className="ra-fade-in">
      <div style={{ marginBottom: 18 }}>
        <h1 style={{ fontSize: 23, fontWeight: 800, margin: 0 }}>المبيعات</h1>
        <p style={{ color: "var(--ink-mute)", fontSize: 14, marginTop: 4 }}>{sales.length} عملية بيع مسجّلة</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14, marginBottom: 22 }}>
        <StatCard icon={Receipt} label="عدد عمليات البيع" value={sales.length} bg="var(--primary-soft)" fg="var(--primary-dark)" />
        <StatCard icon={Wallet} label="إجمالي المبيعات" value={fmtPrice(totalRevenue)} bg="var(--gold-soft)" fg="#7A5F22" />
      </div>

      {sales.length === 0 ? (
        <div className="ra-card" style={{ padding: 40, textAlign: "center" }}>
          <ShoppingBag size={34} color="var(--ink-mute)" style={{ marginBottom: 10 }} />
          <p style={{ color: "var(--ink-mute)", fontWeight: 700 }}>لا توجد عمليات بيع مسجّلة بعد</p>
        </div>
      ) : (
        <div className="ra-card">
          {sales.map((s, i) => (
            <div key={s.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "14px 18px", borderTop: i === 0 ? "none" : "1px solid var(--line)" }}>
              <div style={{ width: 38, height: 38, borderRadius: 10, background: "var(--sage-soft)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <ShoppingBag size={17} color="var(--sage)" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 14, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.name}</div>
                <div style={{ fontSize: 11.5, color: "var(--ink-mute)" }}>
                  {new Date(s.soldAt).toLocaleString("ar-IQ")}{s.soldBy ? ` — ${s.soldBy}` : ""}
                </div>
              </div>
              <div style={{ fontWeight: 800, fontSize: 14.5, color: "var(--primary-dark)", flexShrink: 0 }}>{fmtPrice(s.price)}</div>
              <Badge bg="var(--sage-soft)" fg="var(--sage)" icon={Check}>{s.status}</Badge>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------------------------- Product Form Modal ---------------------------------- */
function ProductFormModal({ initial, can, onClose, onSave, onDelete, pushToast, existingBarcodes }) {
  const isEdit = !!initial;
  const [form, setForm] = useState(() => initial ? { ...initial, benefitsText: initial.benefits.join("\n") } : {
    barcode: genBarcode(), name: "", category: CATEGORIES[0], photo: "", benefitsText: "", description: "", retail: "", wholesale: "", stock: ""
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const photoInputRef = useRef(null);
  const isUploadedPhoto = form.photo && form.photo.startsWith("data:");

  const handlePhotoFile = (file) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) { pushToast("يرجى اختيار ملف صورة صالح", "error"); return; }
    const reader = new FileReader();
    reader.onload = () => set("photo", reader.result);
    reader.readAsDataURL(file);
  };

  const submit = (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.barcode.trim() || form.retail === "" || form.stock === "") {
      pushToast("يرجى تعبئة جميع الحقول المطلوبة", "error"); return;
    }
    const dupe = existingBarcodes.find(b => b.barcode === form.barcode.trim() && b.id !== initial?.id);
    if (dupe) { pushToast("رقم الباركود مستخدم لمنتج آخر بالفعل", "error"); return; }

    onSave({
      id: initial?.id || uid(),
      barcode: form.barcode.trim(),
      name: form.name.trim(),
      category: form.category,
      photo: form.photo.trim(),
      benefits: form.benefitsText.split("\n").map(s => s.trim()).filter(Boolean),
      description: form.description.trim(),
      retail: Number(form.retail) || 0,
      wholesale: Number(form.wholesale) || 0,
      stock: Number(form.stock) || 0,
    });
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(46,35,32,0.45)", zIndex: 300, display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "4vh 16px", overflowY: "auto" }} onClick={onClose}>
      <div className="ra-card ra-pop ra-scroll" style={{ width: "100%", maxWidth: 620, padding: 26 }} onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <h3 style={{ fontSize: 19, fontWeight: 800, margin: 0 }}>{isEdit ? "تعديل المنتج" : "إضافة منتج جديد"}</h3>
          <button type="button" className="ra-icon-btn" onClick={onClose}><X size={17} /></button>
        </div>

        <div style={{ display: "flex", gap: 16, marginBottom: 18, alignItems: "flex-start" }}>
          <ProductPhoto product={form} size={72} rounded={16} />
          <div style={{ flex: 1 }}>
            <label className="ra-label">صورة المنتج</label>
            <div style={{ display: "flex", gap: 8 }}>
              <input className="ra-input" placeholder="رابط صورة (اختياري)" value={isUploadedPhoto ? "" : form.photo}
                onChange={e => set("photo", e.target.value)} />
              <button type="button" className="ra-icon-btn" title="رفع صورة من الجهاز أو الكاميرا" onClick={() => photoInputRef.current.click()}>
                <ImagePlus size={16} />
              </button>
            </div>
            <input ref={photoInputRef} type="file" accept="image/*" capture="environment" style={{ display: "none" }}
              onChange={e => { handlePhotoFile(e.target.files[0]); e.target.value = ""; }} />
            {isUploadedPhoto && (
              <button type="button" onClick={() => set("photo", "")} style={{ background: "none", border: "none", color: "var(--danger)", fontSize: 12, fontWeight: 700, cursor: "pointer", marginTop: 6, padding: 0 }}>
                إزالة الصورة المرفوعة
              </button>
            )}
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 14 }} className="ra-form-grid">
          <div style={{ gridColumn: "1 / -1" }}>
            <label className="ra-label">اسم المنتج *</label>
            <input className="ra-input" value={form.name} onChange={e => set("name", e.target.value)} />
          </div>
          <div>
            <label className="ra-label">الباركود / الرقم التسلسلي *</label>
            <div style={{ display: "flex", gap: 8 }}>
              <input className="ra-input" style={{ fontFamily: "monospace" }} value={form.barcode} onChange={e => set("barcode", e.target.value)} />
              <button type="button" className="ra-icon-btn" title="توليد رقم جديد" onClick={() => set("barcode", genBarcode())}><RefreshCw size={16} /></button>
            </div>
          </div>
          <div>
            <label className="ra-label">الفئة</label>
            <select className="ra-input" value={form.category} onChange={e => set("category", e.target.value)}>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="ra-label">سعر التجزئة (د.ع) *</label>
            <input className="ra-input" type="number" min="0" step="0.01" value={form.retail} onChange={e => set("retail", e.target.value)} />
          </div>
          <div>
            <label className="ra-label">
              سعر الجملة (د.ع) {!can("viewWholesale") && <Lock size={11} style={{ display: "inline", marginInlineStart: 4 }} />}
            </label>
            <input className="ra-input" type="number" min="0" step="0.01" value={form.wholesale} disabled={!can("viewWholesale")}
              onChange={e => set("wholesale", e.target.value)} />
          </div>
          <div style={{ gridColumn: "1 / -1" }}>
            <label className="ra-label">الكمية بالمخزون *</label>
            <input className="ra-input" type="number" min="0" value={form.stock} onChange={e => set("stock", e.target.value)} />
          </div>
          <div style={{ gridColumn: "1 / -1" }}>
            <label className="ra-label">المزايا (سطر لكل ميزة)</label>
            <textarea className="ra-input" rows={3} value={form.benefitsText} onChange={e => set("benefitsText", e.target.value)} placeholder={"ترطيب عميق\nيمنح إشراقة فورية"} />
          </div>
          <div style={{ gridColumn: "1 / -1" }}>
            <label className="ra-label">الوصف</label>
            <textarea className="ra-input" rows={3} value={form.description} onChange={e => set("description", e.target.value)} />
          </div>
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
          {isEdit && onDelete && (
            <button type="button" className="ra-btn ra-btn-danger" onClick={onDelete}><Trash2 size={16} /> حذف</button>
          )}
          <div style={{ flex: 1 }} />
          <button type="button" className="ra-btn ra-btn-ghost" onClick={onClose}>إلغاء</button>
          <button type="button" className="ra-btn ra-btn-primary" onClick={submit}><Save size={16} /> حفظ</button>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Product Detail Modal ---------------------------------- */
function ProductDetailModal({ product, can, onClose, onEdit, onSell }) {
  if (!product) return null;
  const theme = CATEGORY_THEME[product.category] || CATEGORY_THEME["مكياج"];
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(46,35,32,0.45)", zIndex: 290, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }} onClick={onClose}>
      <div className="ra-card ra-pop" style={{ width: "100%", maxWidth: 460, overflow: "hidden" }} onClick={e => e.stopPropagation()}>
        <div style={{ background: theme.bg, padding: "28px 26px", display: "flex", flexDirection: "column", alignItems: "center", position: "relative" }}>
          <button className="ra-icon-btn" style={{ position: "absolute", top: 14, insetInlineEnd: 14, background: "#fff" }} onClick={onClose}><X size={16} /></button>
          <ProductPhoto product={product} size={96} rounded={22} />
          <Badge bg="#fff" fg={theme.fg} icon={Sparkles} >{product.category}</Badge>
          <h2 style={{ fontSize: 19, fontWeight: 800, margin: "10px 0 0", textAlign: "center" }}>{product.name}</h2>
          <div style={{ fontFamily: "monospace", fontSize: 12.5, color: "var(--ink-soft)", marginTop: 4 }}>{product.barcode}</div>
        </div>

        <div style={{ padding: 24 }}>
          <div style={{ display: "flex", gap: 12, marginBottom: 18 }}>
            <div style={{ flex: 1, background: "var(--surface-alt)", borderRadius: 13, padding: "12px 14px", textAlign: "center" }}>
              <div style={{ fontSize: 11.5, color: "var(--ink-mute)", fontWeight: 700 }}>سعر التجزئة</div>
              <div style={{ fontSize: 18, fontWeight: 800, marginTop: 2, color: "var(--primary-dark)" }}>{fmtPrice(product.retail)}</div>
            </div>
            {can("viewWholesale") && (
              <div style={{ flex: 1, background: "var(--surface-alt)", borderRadius: 13, padding: "12px 14px", textAlign: "center" }}>
                <div style={{ fontSize: 11.5, color: "var(--ink-mute)", fontWeight: 700 }}>سعر الجملة</div>
                <div style={{ fontSize: 18, fontWeight: 800, marginTop: 2 }}>{fmtPrice(product.wholesale)}</div>
              </div>
            )}
            <div style={{ flex: 1, background: "var(--surface-alt)", borderRadius: 13, padding: "12px 14px", textAlign: "center" }}>
              <div style={{ fontSize: 11.5, color: "var(--ink-mute)", fontWeight: 700 }}>المخزون</div>
              <div style={{ fontSize: 18, fontWeight: 800, marginTop: 2, color: product.stock <= 5 ? "var(--danger)" : "var(--sage)" }}>{product.stock}</div>
            </div>
          </div>

          {product.benefits?.length > 0 && (
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 13, fontWeight: 800, marginBottom: 8 }}>المزايا</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                {product.benefits.map((b, i) => <Badge key={i} bg="var(--sage-soft)" fg="var(--sage)" icon={Check}>{b}</Badge>)}
              </div>
            </div>
          )}

          {product.description && (
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 13, fontWeight: 800, marginBottom: 6 }}>الوصف</div>
              <p style={{ fontSize: 13.5, color: "var(--ink-soft)", lineHeight: 1.8, margin: 0 }}>{product.description}</p>
            </div>
          )}

          <div style={{ display: "flex", gap: 10 }}>
            {can("sellProducts") && (
              <button className="ra-btn ra-btn-gold" style={{ flex: 1 }} disabled={product.stock <= 0} onClick={onSell}>
                <ShoppingBag size={16} /> {product.stock <= 0 ? "غير متوفر" : "تسجيل عملية بيع"}
              </button>
            )}
            {can("editProducts") && (
              <button className="ra-btn ra-btn-primary" style={{ flex: 1 }} onClick={onEdit}>
                <Pencil size={16} /> تعديل
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------- Products Screen ---------------------------------- */
function ProductsScreen({ products, can, onSave, onDelete, onSell, pushToast, autoOpenAdd, confirm }) {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("الكل");
  const [detail, setDetail] = useState(null);
  const [formOpen, setFormOpen] = useState(autoOpenAdd ? "new" : null);
  const [scanOpen, setScanOpen] = useState(false);
  const searchRef = useRef(null);

  const filtered = useMemo(() => {
    let list = products;
    if (activeCategory !== "الكل") list = list.filter(p => p.category === activeCategory);
    const q = query.trim().toLowerCase();
    if (q) list = list.filter(p => p.name.toLowerCase().includes(q) || p.barcode.includes(q) || p.category.includes(q));
    return list;
  }, [products, query, activeCategory]);

  const PAGE_SIZE = 24;
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  useEffect(() => { setVisibleCount(PAGE_SIZE); }, [query, activeCategory]);
  const visibleList = filtered.slice(0, visibleCount);

  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      const exact = products.find(p => p.barcode === query.trim());
      if (exact) { setDetail(exact); setQuery(""); }
      else if (filtered.length === 1) { setDetail(filtered[0]); setQuery(""); }
    }
  };

  const handleDetected = useCallback((code) => {
    setScanOpen(false);
    const exact = products.find(p => p.barcode === code.trim());
    if (exact) { setDetail(exact); setQuery(""); }
    else { setQuery(code.trim()); pushToast("لم يتم العثور على منتج بهذا الرمز", "warn"); }
  }, [products, pushToast]);

  const editing = formOpen && formOpen !== "new" ? products.find(p => p.id === formOpen) : null;

  return (
    <div className="ra-fade-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, marginBottom: 18, flexWrap: "wrap" }}>
        <div>
          <h1 style={{ fontSize: 23, fontWeight: 800, margin: 0 }}>المنتجات</h1>
          <p style={{ color: "var(--ink-mute)", fontSize: 14, marginTop: 4 }}>{filtered.length} منتج</p>
        </div>
        {can("addProducts") && (
          <button className="ra-btn ra-btn-primary" onClick={() => setFormOpen("new")}>
            <Plus size={16} /> إضافة منتج
          </button>
        )}
      </div>

      <div className="ra-card" style={{ padding: 14, marginBottom: 18 }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          <div style={{ position: "relative", flex: 1 }}>
            <ScanBarcode size={19} style={{ position: "absolute", top: 12, insetInlineStart: 14, color: "var(--primary)" }} />
            <input
              ref={searchRef}
              className="ra-input"
              style={{ paddingInlineStart: 42, fontSize: 15.5, height: 46 }}
              placeholder="امسح الباركود أو ابحث بالاسم / الرقم التسلسلي ثم اضغط Enter"
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={handleKeyDown}
            />
          </div>
          <button type="button" className="ra-btn ra-btn-gold" style={{ height: 46, flexShrink: 0 }} onClick={() => setScanOpen(true)}>
            <Camera size={18} /> <span className="ra-scan-label">مسح بالكاميرا</span>
          </button>
        </div>
        <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 2 }} className="ra-scrollbar-none">
          {["الكل", ...CATEGORIES].map(c => (
            <button key={c} onClick={() => setActiveCategory(c)} className="ra-btn ra-btn-sm"
              style={{
                flexShrink: 0,
                background: activeCategory === c ? "var(--primary)" : "var(--surface-alt)",
                color: activeCategory === c ? "#fff" : "var(--ink-soft)",
              }}>
              {c}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="ra-card" style={{ padding: 40, textAlign: "center" }}>
          <ImageIcon size={34} color="var(--ink-mute)" style={{ marginBottom: 10 }} />
          <p style={{ color: "var(--ink-mute)", fontWeight: 700 }}>لا توجد منتجات مطابقة</p>
        </div>
      ) : (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(230px, 1fr))", gap: 14 }}>
            {visibleList.map(p => {
              const theme = CATEGORY_THEME[p.category] || CATEGORY_THEME["مكياج"];
              return (
                <div key={p.id} className="ra-card" style={{ padding: 16, cursor: "pointer" }} onClick={() => setDetail(p)}>
                  <div style={{ display: "flex", gap: 12, marginBottom: 10 }}>
                    <ProductPhoto product={p} size={56} rounded={14} />
                    <div style={{ minWidth: 0, flex: 1 }}>
                      <div style={{ fontWeight: 800, fontSize: 14.5, lineHeight: 1.35, overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" }}>{p.name}</div>
                      <div style={{ fontSize: 11.5, color: "var(--ink-mute)", fontFamily: "monospace", marginTop: 3 }}>{p.barcode}</div>
                    </div>
                  </div>
                  <Badge bg={theme.bg} fg={theme.fg}>{p.category}</Badge>
                  <div className="ra-hairline" style={{ marginTop: 12, paddingTop: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div>
                      <div style={{ fontWeight: 800, fontSize: 15, color: "var(--primary-dark)" }}>{fmtPrice(p.retail)}</div>
                      {can("viewWholesale") && <div style={{ fontSize: 11.5, color: "var(--ink-mute)" }}>جملة: {fmtPrice(p.wholesale)}</div>}
                    </div>
                    <Badge bg={p.stock <= 5 ? "var(--danger-soft)" : "var(--sage-soft)"} fg={p.stock <= 5 ? "var(--danger)" : "var(--sage)"}>{p.stock} بالمخزون</Badge>
                  </div>
                  <div style={{ display: "flex", gap: 8, marginTop: 12 }} onClick={e => e.stopPropagation()}>
                    {can("sellProducts") && (
                      <button className="ra-btn ra-btn-gold ra-btn-sm" style={{ flex: 1 }} disabled={p.stock <= 0} onClick={() => onSell(p)}>
                        <ShoppingBag size={13} /> بيع
                      </button>
                    )}
                    {can("editProducts") && (
                      <button className="ra-btn ra-btn-ghost ra-btn-sm" style={{ flex: 1 }} onClick={() => setFormOpen(p.id)}><Pencil size={13} /> تعديل</button>
                    )}
                    {can("deleteProducts") && (
                      <button className="ra-btn ra-btn-danger ra-btn-sm" onClick={() => confirm({
                        title: "حذف المنتج؟", danger: true, confirmLabel: "حذف",
                        message: `سيتم حذف "${p.name}" نهائياً من قاعدة البيانات.`,
                        onConfirm: () => onDelete(p.id)
                      })}><Trash2 size={13} /></button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          {filtered.length > visibleCount && (
            <button className="ra-btn ra-btn-ghost" style={{ width: "100%", marginTop: 16 }} onClick={() => setVisibleCount(v => v + PAGE_SIZE)}>
              عرض المزيد ({filtered.length - visibleCount} متبقٍ)
            </button>
          )}
        </>
      )}

      <ProductDetailModal product={detail} can={can} onClose={() => setDetail(null)}
        onEdit={() => { setFormOpen(detail.id); setDetail(null); }}
        onSell={() => { onSell(detail); setDetail(null); }} />

      {formOpen && (
        <ProductFormModal
          initial={editing}
          can={can}
          existingBarcodes={products}
          pushToast={pushToast}
          onClose={() => setFormOpen(null)}
          onSave={(data) => { onSave(data, !editing); setFormOpen(null); }}
          onDelete={editing ? () => confirm({
            title: "حذف المنتج؟", danger: true, confirmLabel: "حذف",
            message: `سيتم حذف "${editing.name}" نهائياً من قاعدة البيانات.`,
            onConfirm: () => { onDelete(editing.id); setFormOpen(null); }
          }) : null}
        />
      )}

      {scanOpen && <CameraScanModal onClose={() => setScanOpen(false)} onDetect={handleDetected} />}
    </div>
  );
}


/* ---------------------------------- Users Screen ---------------------------------- */
function UserFormModal({ initial, onClose, onSave, pushToast, existingEmails }) {
  const isEdit = !!initial;
  const [form, setForm] = useState(() => initial ? { ...initial } : {
    name: "", email: "", code: String(Math.floor(100000 + Math.random() * 899999)), role: "employee", permissions: { ...DEFAULT_EMPLOYEE_PERMS }
  });
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const setPerm = (k, v) => setForm(f => ({ ...f, permissions: { ...f.permissions, [k]: v } }));

  const submit = (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.email.trim() || !form.code.trim()) { pushToast("يرجى تعبئة جميع الحقول", "error"); return; }
    const dupe = existingEmails.find(u => u.email.toLowerCase() === form.email.trim().toLowerCase() && u.id !== initial?.id);
    if (dupe) { pushToast("البريد الإلكتروني مستخدم بالفعل", "error"); return; }
    onSave({
      id: initial?.id || uid(),
      name: form.name.trim(), email: form.email.trim(), code: form.code.trim(), role: form.role,
      permissions: form.role === "manager" ? { ...ALL_PERMS_TRUE } : form.permissions
    });
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(46,35,32,0.45)", zIndex: 300, display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "4vh 16px", overflowY: "auto" }} onClick={onClose}>
      <div className="ra-card ra-pop" style={{ width: "100%", maxWidth: 520, padding: 26 }} onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <h3 style={{ fontSize: 19, fontWeight: 800, margin: 0 }}>{isEdit ? "تعديل المستخدم" : "إضافة مستخدم"}</h3>
          <button type="button" className="ra-icon-btn" onClick={onClose}><X size={17} /></button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div>
            <label className="ra-label">الاسم الكامل</label>
            <input className="ra-input" value={form.name} onChange={e => set("name", e.target.value)} />
          </div>
          <div>
            <label className="ra-label">البريد الإلكتروني</label>
            <input className="ra-input" type="email" value={form.email} onChange={e => set("email", e.target.value)} />
          </div>
          <div>
            <label className="ra-label">رمز الدخول</label>
            <div style={{ display: "flex", gap: 8 }}>
              <input className="ra-input" style={{ fontFamily: "monospace" }} value={form.code} onChange={e => set("code", e.target.value)} />
              <button type="button" className="ra-icon-btn" title="توليد رمز جديد" onClick={() => set("code", String(Math.floor(100000 + Math.random() * 899999)))}><RefreshCw size={16} /></button>
            </div>
          </div>
          <div>
            <label className="ra-label">الدور الوظيفي</label>
            <div style={{ display: "flex", gap: 10 }}>
              {[["manager", "مدير"], ["employee", "موظف"]].map(([val, label]) => (
                <button type="button" key={val} onClick={() => set("role", val)} className="ra-btn ra-btn-sm" style={{
                  flex: 1, background: form.role === val ? "var(--primary)" : "var(--surface-alt)",
                  color: form.role === val ? "#fff" : "var(--ink-soft)"
                }}>{label}</button>
              ))}
            </div>
          </div>

          {form.role === "employee" ? (
            <div>
              <label className="ra-label">الصلاحيات</label>
              <div className="ra-card" style={{ padding: 4 }}>
                {PERMISSION_KEYS.map((k, i) => (
                  <div key={k} style={{
                    display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 12px",
                    borderTop: i === 0 ? "none" : "1px solid var(--line)"
                  }}>
                    <span style={{ fontSize: 13.5, fontWeight: 600 }}>{PERMISSION_LABELS[k]}</span>
                    <Toggle on={!!form.permissions[k]} onClick={() => setPerm(k, !form.permissions[k])} />
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div style={{ display: "flex", alignItems: "center", gap: 8, background: "var(--gold-soft)", padding: "10px 14px", borderRadius: 11, fontSize: 13, color: "#7A5F22", fontWeight: 700 }}>
              <ShieldCheck size={16} /> حساب المدير يملك صلاحية الوصول الكامل تلقائياً
            </div>
          )}
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 22 }}>
          <button type="button" className="ra-btn ra-btn-ghost" style={{ flex: 1 }} onClick={onClose}>إلغاء</button>
          <button type="button" className="ra-btn ra-btn-primary" style={{ flex: 1 }} onClick={submit}><Save size={16} /> حفظ</button>
        </div>
      </div>
    </div>
  );
}

function UsersScreen({ users, currentUser, onSave, onDelete, pushToast, confirm }) {
  const [formOpen, setFormOpen] = useState(null);
  const editing = formOpen && formOpen !== "new" ? users.find(u => u.id === formOpen) : null;
  const managerCount = users.filter(u => u.role === "manager").length;

  return (
    <div className="ra-fade-in">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, marginBottom: 18, flexWrap: "wrap" }}>
        <div>
          <h1 style={{ fontSize: 23, fontWeight: 800, margin: 0 }}>المستخدمون</h1>
          <p style={{ color: "var(--ink-mute)", fontSize: 14, marginTop: 4 }}>{users.length} حساب</p>
        </div>
        <button className="ra-btn ra-btn-primary" onClick={() => setFormOpen("new")}><UserPlus size={16} /> إضافة مستخدم</button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(270px, 1fr))", gap: 14 }}>
        {users.map(u => (
          <div key={u.id} className="ra-card" style={{ padding: 18 }}>
            <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 12 }}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: "var(--primary-soft)", color: "var(--primary-dark)", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800 }}>{u.name.charAt(0)}</div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 800, fontSize: 14.5, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{u.name}</div>
                <div style={{ fontSize: 12, color: "var(--ink-mute)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{u.email}</div>
              </div>
            </div>
            <Badge bg={u.role === "manager" ? "var(--gold-soft)" : "var(--sage-soft)"} fg={u.role === "manager" ? "#7A5F22" : "var(--sage)"} icon={u.role === "manager" ? ShieldCheck : Users}>
              {u.role === "manager" ? "مدير" : "موظف"}
            </Badge>
            {u.role === "employee" && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 5, marginTop: 10 }}>
                {PERMISSION_KEYS.filter(k => u.permissions[k]).map(k => (
                  <span key={k} style={{ fontSize: 10.5, background: "var(--surface-alt)", color: "var(--ink-soft)", padding: "3px 8px", borderRadius: 999, fontWeight: 700 }}>{PERMISSION_LABELS[k]}</span>
                ))}
                {PERMISSION_KEYS.filter(k => u.permissions[k]).length === 0 && (
                  <span style={{ fontSize: 11.5, color: "var(--ink-mute)" }}>لا توجد صلاحيات إضافية</span>
                )}
              </div>
            )}
            <div className="ra-hairline" style={{ marginTop: 14, paddingTop: 12, display: "flex", gap: 8 }}>
              <button className="ra-btn ra-btn-ghost ra-btn-sm" style={{ flex: 1 }} onClick={() => setFormOpen(u.id)}><Pencil size={13} /> تعديل</button>
              <button className="ra-btn ra-btn-danger ra-btn-sm" disabled={u.id === currentUser.id || (u.role === "manager" && managerCount <= 1)}
                onClick={() => confirm({
                  title: "حذف المستخدم؟", danger: true, confirmLabel: "حذف",
                  message: `سيتم حذف حساب "${u.name}" نهائياً.`,
                  onConfirm: () => onDelete(u.id)
                })}>
                <Trash2 size={13} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {formOpen && (
        <UserFormModal initial={editing} existingEmails={users} pushToast={pushToast}
          onClose={() => setFormOpen(null)}
          onSave={(data) => { onSave(data, !editing); setFormOpen(null); }} />
      )}
    </div>
  );
}

/* ---------------------------------- Database Screen ---------------------------------- */
function DatabaseScreen({ products, users, setProducts, setUsers, pushToast, confirm, currentUser, setCurrentUser }) {
  const importRef = useRef(null);
  const restoreRef = useRef(null);

  const downloadJSON = (obj, filename) => {
    const blob = new Blob([JSON.stringify(obj, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const buildSnapshot = () => ({ app: "leen", version: 1, exportedAt: new Date().toISOString(), users, products });

  const handleExport = () => { downloadJSON(buildSnapshot(), `leen-export_${nowStamp()}.json`); pushToast("تم تصدير قاعدة البيانات بنجاح"); };
  const handleBackup = () => { downloadJSON(buildSnapshot(), `leen-backup_${nowStamp()}.json`); pushToast("تم إنشاء نسخة احتياطية بنجاح"); };

  const readFile = (file, cb) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (!Array.isArray(data.products) || !Array.isArray(data.users)) throw new Error("bad shape");
        cb(data);
      } catch {
        pushToast("الملف غير صالح أو تالف", "error");
      }
    };
    reader.readAsText(file);
  };

  const applyImport = (data, label) => {
    confirm({
      title: label === "restore" ? "استعادة النسخة الاحتياطية؟" : "استيراد قاعدة البيانات؟",
      danger: true, confirmLabel: "متابعة",
      message: "سيتم استبدال جميع المنتجات والمستخدمين الحاليين بمحتوى الملف المحدد. لا يمكن التراجع عن هذا الإجراء.",
      onConfirm: () => {
        setProducts(data.products);
        setUsers(data.users);
        const stillExists = data.users.find(u => u.id === currentUser.id && u.email === currentUser.email);
        if (stillExists) setCurrentUser(stillExists);
        pushToast(label === "restore" ? "تمت استعادة النسخة الاحتياطية" : "تم استيراد قاعدة البيانات بنجاح");
      }
    });
  };

  const excelRef = useRef(null);

  const findColumn = (row, keywords) => Object.keys(row).find(k => {
    const key = String(k ?? "").trim().toLowerCase();
    return keywords.some(kw => key.includes(kw));
  });

  const parseProductRows = (rows) => {
    if (!rows.length) return [];
    const sample = rows[0];
    const barcodeKey = findColumn(sample, ["barcode", "باركود", "كود", "رمز", "serial", "تسلسلي"]);
    const nameKey = findColumn(sample, ["name", "اسم", "منتج", "مادة"]);
    const retailKey = findColumn(sample, ["retail", "مفرد", "تجزئة", "بيع"]);
    const wholesaleKey = findColumn(sample, ["wholesale", "جملة", "كلفة", "شراء"]);
    const categoryKey = findColumn(sample, ["category", "فئة", "قسم"]);
    const stockKey = findColumn(sample, ["stock", "مخزون", "كمية", "عدد"]);
    if (!nameKey) return [];
    return rows.map(r => {
      const name = String(r[nameKey] ?? "").trim();
      if (!name) return null;
      const cat = categoryKey ? String(r[categoryKey] ?? "").trim() : "";
      return {
        barcode: barcodeKey ? String(r[barcodeKey] ?? "").trim() : "",
        name,
        category: CATEGORIES.includes(cat) ? cat : CATEGORIES[0],
        retail: Number(retailKey ? r[retailKey] : 0) || 0,
        wholesale: Number(wholesaleKey ? r[wholesaleKey] : 0) || 0,
        stock: Number(stockKey ? r[stockKey] : 0) || 0,
      };
    }).filter(Boolean);
  };

  const handleExcelFile = async (file) => {
    let XLSX;
    try {
      XLSX = await import("xlsx");
    } catch {
      pushToast("تعذّر تحميل أداة قراءة الإكسل، تحقق من اتصال الإنترنت", "error");
      return;
    }
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = new Uint8Array(evt.target.result);
        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });
        const parsed = parseProductRows(rows);
        if (!parsed.length) { pushToast("تعذّر التعرف على أعمدة الملف — تأكد من وجود عمود لاسم المنتج", "error"); return; }
        let added = 0, updated = 0;
        const next = [...products];
        parsed.forEach(item => {
          const idx = item.barcode ? next.findIndex(p => p.barcode === item.barcode) : -1;
          if (idx >= 0) {
            next[idx] = {
              ...next[idx], name: item.name, category: item.category,
              retail: item.retail || next[idx].retail, wholesale: item.wholesale || next[idx].wholesale,
              stock: item.stock || next[idx].stock,
            };
            updated++;
          } else {
            next.push({ id: uid(), barcode: item.barcode || genBarcode(), name: item.name, category: item.category, photo: "", benefits: [], description: "", retail: item.retail, wholesale: item.wholesale, stock: item.stock });
            added++;
          }
        });
        confirm({
          title: "استيراد المنتجات من ملف إكسل؟",
          confirmLabel: "استيراد",
          message: `تم العثور على ${parsed.length} صفاً — سيتم إضافة ${added} منتج جديد وتحديث ${updated} منتج موجود (بحسب تطابق الباركود).`,
          onConfirm: () => { setProducts(next); pushToast("تم استيراد المنتجات من ملف الإكسل بنجاح"); }
        });
      } catch {
        pushToast("تعذّرت قراءة ملف الإكسل، تأكد من صيغة الملف", "error");
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleFullReset = () => {
    confirm({
      title: "إعادة تعيين قاعدة البيانات بالكامل؟", danger: true, confirmLabel: "إعادة التعيين",
      message: "سيتم حذف جميع المنتجات وحسابات المستخدمين نهائياً، والاحتفاظ بحسابك الحالي فقط كمدير. هذا الإجراء لا يمكن التراجع عنه.",
      onConfirm: () => {
        const freshManager = { ...currentUser, role: "manager", permissions: { ...ALL_PERMS_TRUE } };
        setUsers([freshManager]);
        setProducts([]);
        setCurrentUser(freshManager);
        pushToast("تمت إعادة تعيين قاعدة البيانات بالكامل");
      }
    });
  };

  return (
    <div className="ra-fade-in">
      <div style={{ marginBottom: 22 }}>
        <h1 style={{ fontSize: 23, fontWeight: 800, margin: 0 }}>قاعدة البيانات</h1>
        <p style={{ color: "var(--ink-mute)", fontSize: 14, marginTop: 4 }}>استيراد، تصدير، نسخ احتياطي، واستعادة كامل بيانات المتجر</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16 }}>
        <div className="ra-card" style={{ padding: 22 }}>
          <div style={{ width: 42, height: 42, borderRadius: 12, background: "var(--primary-soft)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 12 }}>
            <Download size={19} color="var(--primary-dark)" />
          </div>
          <h3 style={{ fontSize: 15.5, fontWeight: 800, margin: "0 0 6px" }}>تصدير قاعدة البيانات</h3>
          <p style={{ fontSize: 13, color: "var(--ink-mute)", lineHeight: 1.7, margin: "0 0 14px" }}>احفظ نسخة كاملة من المنتجات والمستخدمين كملف واحد يمكن نقله بسهولة.</p>
          <button className="ra-btn ra-btn-primary" style={{ width: "100%" }} onClick={handleExport}><Download size={16} /> تصدير الآن</button>
        </div>

        <div className="ra-card" style={{ padding: 22 }}>
          <div style={{ width: 42, height: 42, borderRadius: 12, background: "var(--sage-soft)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 12 }}>
            <Upload size={19} color="var(--sage)" />
          </div>
          <h3 style={{ fontSize: 15.5, fontWeight: 800, margin: "0 0 6px" }}>استيراد قاعدة البيانات</h3>
          <p style={{ fontSize: 13, color: "var(--ink-mute)", lineHeight: 1.7, margin: "0 0 14px" }}>استورد ملف بيانات لاستبدال المحتوى الحالي بالكامل.</p>
          <button className="ra-btn ra-btn-ghost" style={{ width: "100%" }} onClick={() => importRef.current.click()}><Upload size={16} /> اختيار ملف</button>
          <input ref={importRef} type="file" accept="application/json" style={{ display: "none" }}
            onChange={e => { const f = e.target.files[0]; if (f) readFile(f, (d) => applyImport(d, "import")); e.target.value = ""; }} />
        </div>

        <div className="ra-card" style={{ padding: 22 }}>
          <div style={{ width: 42, height: 42, borderRadius: 12, background: "var(--sage-soft)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 12 }}>
            <FileSpreadsheet size={19} color="var(--sage)" />
          </div>
          <h3 style={{ fontSize: 15.5, fontWeight: 800, margin: "0 0 6px" }}>استيراد منتجات من إكسل</h3>
          <p style={{ fontSize: 13, color: "var(--ink-mute)", lineHeight: 1.7, margin: "0 0 14px" }}>ارفع ملف Excel يحتوي على أعمدة: الباركود، اسم المنتج، السعر، والكمية — سيتم إضافة الجديد وتحديث المطابق تلقائياً.</p>
          <button className="ra-btn ra-btn-gold" style={{ width: "100%" }} onClick={() => excelRef.current.click()}><FileSpreadsheet size={16} /> اختيار ملف إكسل</button>
          <input ref={excelRef} type="file" accept=".xlsx,.xls,.csv" style={{ display: "none" }}
            onChange={e => { const f = e.target.files[0]; if (f) handleExcelFile(f); e.target.value = ""; }} />
        </div>

        <div className="ra-card" style={{ padding: 22 }}>
          <div style={{ width: 42, height: 42, borderRadius: 12, background: "var(--gold-soft)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 12 }}>
            <Database size={19} color="#7A5F22" />
          </div>
          <h3 style={{ fontSize: 15.5, fontWeight: 800, margin: "0 0 6px" }}>نسخ احتياطي</h3>
          <p style={{ fontSize: 13, color: "var(--ink-mute)", lineHeight: 1.7, margin: "0 0 14px" }}>ينصح بإنشاء نسخة احتياطية دورياً كإجراء وقائي قبل أي تعديلات كبيرة.</p>
          <button className="ra-btn ra-btn-gold" style={{ width: "100%" }} onClick={handleBackup}><Database size={16} /> إنشاء نسخة احتياطية</button>
        </div>

        <div className="ra-card" style={{ padding: 22 }}>
          <div style={{ width: 42, height: 42, borderRadius: 12, background: "var(--surface-alt)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 12 }}>
            <RefreshCw size={19} color="var(--ink-soft)" />
          </div>
          <h3 style={{ fontSize: 15.5, fontWeight: 800, margin: "0 0 6px" }}>استعادة نسخة احتياطية</h3>
          <p style={{ fontSize: 13, color: "var(--ink-mute)", lineHeight: 1.7, margin: "0 0 14px" }}>استعد بياناتك من ملف نسخة احتياطية محفوظة مسبقاً.</p>
          <button className="ra-btn ra-btn-ghost" style={{ width: "100%" }} onClick={() => restoreRef.current.click()}><Upload size={16} /> اختيار نسخة احتياطية</button>
          <input ref={restoreRef} type="file" accept="application/json" style={{ display: "none" }}
            onChange={e => { const f = e.target.files[0]; if (f) readFile(f, (d) => applyImport(d, "restore")); e.target.value = ""; }} />
        </div>

        <div className="ra-card" style={{ padding: 22, borderColor: "var(--danger-soft)" }}>
          <div style={{ width: 42, height: 42, borderRadius: 12, background: "var(--danger-soft)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 12 }}>
            <TriangleAlert size={19} color="var(--danger)" />
          </div>
          <h3 style={{ fontSize: 15.5, fontWeight: 800, margin: "0 0 6px", color: "var(--danger)" }}>إعادة تعيين كاملة</h3>
          <p style={{ fontSize: 13, color: "var(--ink-mute)", lineHeight: 1.7, margin: "0 0 14px" }}>حذف جميع المنتجات وحسابات المستخدمين، وبدء التطبيق من جديد بحسابك فقط.</p>
          <button className="ra-btn ra-btn-danger" style={{ width: "100%" }} onClick={handleFullReset}><RefreshCw size={16} /> إعادة التعيين بالكامل</button>
        </div>
      </div>

      <div className="ra-card" style={{ padding: "16px 20px", marginTop: 16, display: "flex", gap: 10, alignItems: "flex-start" }}>
        <ShieldCheck size={18} color="var(--gold)" style={{ flexShrink: 0, marginTop: 2 }} />
        <p style={{ fontSize: 12.5, color: "var(--ink-mute)", lineHeight: 1.8, margin: 0 }}>
          تُحفظ البيانات داخل الجلسة الحالية فقط. لضمان عدم فقدان أي تعديلات، يُنصح بتصدير قاعدة البيانات أو إنشاء نسخة احتياطية بشكل دوري وحفظها على جهازك.
        </p>
      </div>
    </div>
  );
}

/* ---------------------------------- App ---------------------------------- */
export default function LeenApp() {
  const [users, setUsers] = useState(seedUsers);
  const [products, setProducts] = useState(seedProducts);
  const [sales, setSales] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [screen, setScreen] = useState("dashboard");
  const [screenParams, setScreenParams] = useState({});
  const [mobileOpen, setMobileOpen] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [confirmData, setConfirmData] = useState(null);

  const pushToast = useCallback((msg, type = "success") => {
    const id = uid();
    setToasts(t => [...t, { id, msg, type }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3200);
  }, []);

  const can = useCallback((perm) => {
    if (!currentUser) return false;
    if (currentUser.role === "manager") return true;
    return !!currentUser.permissions?.[perm];
  }, [currentUser]);

  const go = (s, params = {}) => { setScreen(s); setScreenParams(params); };

  const handleLogin = (u) => { setCurrentUser(u); go("dashboard"); pushToast(`مرحباً بعودتك، ${u.name.split(" ")[0]}`); };
  const handleLogout = () => { setCurrentUser(null); go("dashboard"); };

  const saveProduct = (data, isNew) => {
    setProducts(prev => isNew ? [data, ...prev] : prev.map(p => p.id === data.id ? data : p));
    pushToast(isNew ? "تمت إضافة المنتج بنجاح" : "تم تحديث المنتج بنجاح");
  };
  const deleteProduct = (id) => { setProducts(prev => prev.filter(p => p.id !== id)); pushToast("تم حذف المنتج"); };

  const recordSale = useCallback((product) => {
    if (!product || product.stock <= 0) { pushToast("الكمية غير متوفرة بالمخزون", "error"); return; }
    setProducts(prev => prev.map(p => p.id === product.id ? { ...p, stock: p.stock - 1 } : p));
    setSales(prev => [{
      id: uid(), productId: product.id, name: product.name, barcode: product.barcode, category: product.category,
      price: product.retail, status: "تم البيع", soldAt: new Date().toISOString(), soldBy: currentUser?.name,
    }, ...prev]);
    pushToast(`تم تسجيل بيع "${product.name}"`);
  }, [pushToast, currentUser]);

  const saveUser = (data, isNew) => {
    setUsers(prev => isNew ? [...prev, data] : prev.map(u => u.id === data.id ? data : u));
    if (currentUser && data.id === currentUser.id) setCurrentUser(data);
    pushToast(isNew ? "تمت إضافة المستخدم" : "تم تحديث بيانات المستخدم");
  };
  const deleteUser = (id) => { setUsers(prev => prev.filter(u => u.id !== id)); pushToast("تم حذف المستخدم"); };

  const screenTitles = { dashboard: "لوحة التحكم", products: "المنتجات", sales: "المبيعات", users: "المستخدمون", database: "قاعدة البيانات" };

  if (!currentUser) {
    return (
      <div className="ra-root">
        <style>{GLOBAL_CSS}</style>
        <LoginScreen users={users} onLogin={handleLogin} pushToast={pushToast} />
        <Toast toasts={toasts} />
      </div>
    );
  }

  return (
    <div className="ra-root" dir="rtl" lang="ar">
      <style>{GLOBAL_CSS}</style>
      <style>{`
        @media (max-width:860px){ .ra-form-grid{ grid-template-columns: 1fr !important; } .ra-dash-grid{ grid-template-columns: 1fr !important; } .ra-scan-label{ display:none; } }
      `}</style>

      <Sidebar user={currentUser} screen={screen} go={go} can={can} onLogout={handleLogout} />
      <MobileTop user={currentUser} title={screenTitles[screen]} onMenu={() => setMobileOpen(true)} />
      <MobileDrawer open={mobileOpen} onClose={() => setMobileOpen(false)} user={currentUser} screen={screen} go={go} can={can} onLogout={handleLogout} />

      <main className="ra-main" style={{ paddingInlineEnd: 240, minHeight: "100vh" }}>
        <div style={{ maxWidth: 1180, margin: "0 auto", padding: "28px 24px 60px" }}>
          {screen === "dashboard" && <DashboardScreen products={products} users={users} user={currentUser} can={can} go={go} />}
          {screen === "products" && (
            <ProductsScreen products={products} can={can} onSave={saveProduct} onDelete={(id) => deleteProduct(id)}
              onSell={recordSale} pushToast={pushToast} autoOpenAdd={screenParams.openAdd} confirm={setConfirmData} />
          )}
          {screen === "sales" && can("sellProducts") && <SalesScreen sales={sales} />}
          {screen === "users" && can("manageUsers") && (
            <UsersScreen users={users} currentUser={currentUser} onSave={saveUser} onDelete={deleteUser} pushToast={pushToast} confirm={setConfirmData} />
          )}
          {screen === "database" && can("manageDatabase") && (
            <DatabaseScreen products={products} users={users} setProducts={setProducts} setUsers={setUsers}
              pushToast={pushToast} confirm={setConfirmData} currentUser={currentUser} setCurrentUser={setCurrentUser} />
          )}
        </div>
      </main>

      <Toast toasts={toasts} />
      <ConfirmModal data={confirmData} onClose={() => setConfirmData(null)} />
    </div>
  );
}
